import CoreGraphics
import AppKit

/// Turns normalized touch coordinates from the phone into mouse events on a
/// target display. Touch semantics: finger down = left button down, finger
/// move = drag, finger up = button up — i.e. the phone acts as a touchscreen.
final class InputInjector {

    private let displayID: CGDirectDisplayID
    private var isDown = false
    private var lastPoint = CGPoint.zero
    var lastTouchPoint: CGPoint { lastPoint }
    // A real event source (vs nil) plus clickState=1 below: menu tracking
    // treats sourceless/zero-click synthetic clicks as malformed — menus
    // open but their tracking session breaks, leaving zombie menu windows
    // composited on the display (visible in the stream, unclickable).
    private let source = CGEventSource(stateID: .hidSystemState)

    init(displayID: CGDirectDisplayID) {
        self.displayID = displayID
    }

    static func ensureAccessibilityPermission() -> Bool {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue(): true] as CFDictionary
        let trusted = AXIsProcessTrustedWithOptions(options)
        if !trusted {
            Log.info("Accessibility permission missing — prompt requested")
        }
        return trusted
    }

    /// x/y are normalized [0,1] in video space (origin top-left).
    func handleTouch(phase: String, x: Double, y: Double) {
        guard ReceiverValidation.touch(x: x, y: y) else { return }
        let bounds = CGDisplayBounds(displayID)   // global CG coords, y-down
        let point = CGPoint(
            x: bounds.origin.x + x * bounds.width,
            y: bounds.origin.y + y * bounds.height
        )
        lastPoint = point

        let type: CGEventType
        // Click count on the release. A cancel means "a second finger joined,
        // this was a scroll, not a tap" — but there is no CGEvent for undoing a
        // press, and a plain up over the press point is indistinguishable from a
        // click, so every two-finger scroll opened whatever was under finger one.
        // Releasing with clickCount 0 keeps the button state honest while telling
        // AppKit and WebKit not to synthesize a click. Only the cancel path gets
        // 0: a zero-click *down* is what breaks menu tracking (see above).
        var clickState = 1
        switch phase {
        case "began":
            type = .leftMouseDown
            isDown = true
        case "moved":
            type = isDown ? .leftMouseDragged : .mouseMoved
        case "ended":
            guard isDown else { return }   // spurious up without a down
            type = .leftMouseUp
            isDown = false
        case "cancelled":
            guard isDown else { return }
            type = .leftMouseUp
            isDown = false
            clickState = 0
        default:
            return
        }

        guard let event = CGEvent(mouseEventSource: source, mouseType: type,
                                  mouseCursorPosition: point, mouseButton: .left) else { return }
        event.setIntegerValueField(.mouseEventClickState, value: Int64(clickState))
        event.post(tap: .cghidEventTap)
    }

    /// dx/dy in display pixels, natural-scrolling sign from the phone.
    /// Scroll events take points, so convert via the display's pixel scale.
    func handleScroll(dx: Double, dy: Double) {
        guard ReceiverValidation.scroll(dx: dx, dy: dy) else { return }
        let bounds = CGDisplayBounds(displayID)
        let scale = bounds.width > 0 ? Double(CGDisplayPixelsWide(displayID)) / bounds.width : 2
        guard let event = CGEvent(scrollWheelEvent2Source: source, units: .pixel,
                                  wheelCount: 2,
                                  wheel1: Int32((dy / scale).rounded()),
                                  wheel2: Int32((dx / scale).rounded()),
                                  wheel3: 0) else { return }
        event.post(tap: .cghidEventTap)
    }

    func insertText(_ text: String) {
        guard AXIsProcessTrusted(), RemoteText.isValid(text) else { return }
        for chunk in RemoteText.chunks(text) {
            let chars = Array(chunk.utf16)
            for down in [true, false] {
                guard let event = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: down) else { continue }
                event.flags = []
                chars.withUnsafeBufferPointer {
                    event.keyboardSetUnicodeString(stringLength: chars.count, unicodeString: $0.baseAddress)
                }
                event.post(tap: .cghidEventTap)
            }
        }
    }

    func pressKey(_ key: RemoteKey) {
        guard AXIsProcessTrusted() else { return }
        let code: CGKeyCode
        var flags: CGEventFlags = []
        switch key {
        case .backspace: code = 51
        case .enter: code = 36
        case .tab: code = 48
        case .escape: code = 53
        case .left: code = 123
        case .right: code = 124
        case .up: code = 126
        case .down: code = 125
        case .selectAll: code = 0; flags = .maskCommand
        case .copy: code = 8; flags = .maskCommand
        case .paste: code = 9; flags = .maskCommand
        case .undo: code = 6; flags = .maskCommand
        }
        for down in [true, false] {
            let event = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: down)
            event?.flags = down ? flags : []
            event?.post(tap: .cghidEventTap)
        }
    }

    func releaseHeldButton() {
        guard isDown else { return }
        isDown = false
        let event = CGEvent(mouseEventSource: source, mouseType: .leftMouseUp,
                            mouseCursorPosition: lastPoint, mouseButton: .left)
        event?.setIntegerValueField(.mouseEventClickState, value: 0)
        event?.post(tap: .cghidEventTap)
    }
}
