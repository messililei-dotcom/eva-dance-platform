import Foundation

enum ReceiverValidation {
    static func panel(width: Int, height: Int, scale: Double) -> Bool {
        (320...8192).contains(width) && (320...8192).contains(height)
            && width * height <= 40_000_000 && scale.isFinite && (1...4).contains(scale)
    }

    static func touch(x: Double, y: Double) -> Bool {
        x.isFinite && y.isFinite && (0...1).contains(x) && (0...1).contains(y)
    }

    static func scroll(dx: Double, dy: Double) -> Bool {
        dx.isFinite && dy.isFinite && abs(dx) <= 100_000 && abs(dy) <= 100_000
    }
}
