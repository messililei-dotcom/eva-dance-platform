import SwiftUI

struct PurchaseAccessView: View {
    @ObservedObject private var language = LanguageSettings.shared
    @ObservedObject var store: PurchaseStore
    let connectionReady: Bool
    @State private var confirmsTrial = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label(L10n.text("commerce.title"), systemImage: "display.2").font(.headline)
            Text(L10n.text("commerce.features")).font(.subheadline).foregroundStyle(.secondary)
            Text(L10n.text(store.state.localizationKey))
                .font(.headline)
                .accessibilityIdentifier("commerce-state-\(store.state.rawValue)")
            if store.state == .trial {
                Text(L10n.format("commerce.remaining", store.countdown))
                    .monospacedDigit().accessibilityIdentifier("commerce-countdown")
            }
            if store.state != .unlocked {
                Text(L10n.text("commerce.oneTime")).font(.subheadline)
                Button {
                    Task { await store.purchaseFullUnlock() }
                } label: {
                    Text(store.fullPrice.map { L10n.format("commerce.buy", $0) } ?? L10n.text("commerce.loadingPrice"))
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
                .disabled(!store.canPurchase)
                .accessibilityIdentifier("commerce-buy")
                if store.state == .notStarted {
                    Button(L10n.text("commerce.startTrial")) { confirmsTrial = true }
                        .frame(minHeight: 44)
                        .disabled(!connectionReady || !store.canStartTrial)
                        .accessibilityIdentifier("commerce-trial")
                    Text(L10n.text(connectionReady ? "commerce.trialSummary" : "commerce.connectFirst"))
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            if let message = store.messageKey {
                Text(L10n.text(message)).font(.subheadline).foregroundStyle(.secondary)
                    .accessibilityIdentifier("commerce-message")
            }
            HStack {
                Button(L10n.text("commerce.restore")) { Task { await store.restore() } }
                    .frame(minHeight: 44).disabled(store.busy)
                    .accessibilityIdentifier("commerce-restore")
                Spacer()
                if store.state != .unlocked {
                    Button(L10n.text("commerce.retry")) {
                        Task { await store.refreshEntitlements(); await store.loadProducts() }
                    }.frame(minHeight: 44).disabled(store.busy || store.loadingProducts)
                }
            }
            if store.busy || store.loadingProducts { ProgressView().accessibilityLabel(L10n.text("commerce.processing")) }
        }
        .frame(maxWidth: 500, alignment: .leading)
        .alert(L10n.text("commerce.startTrial"), isPresented: $confirmsTrial) {
            Button(L10n.text("commerce.confirmTrial")) { Task { await store.startTrial(connectionReady: connectionReady) } }
            Button(L10n.text("commerce.cancel"), role: .cancel) { }
        } message: {
            Text(L10n.format("commerce.trialDisclosure", store.fullPrice ?? L10n.text("commerce.loadingPrice")))
        }
    }
}
