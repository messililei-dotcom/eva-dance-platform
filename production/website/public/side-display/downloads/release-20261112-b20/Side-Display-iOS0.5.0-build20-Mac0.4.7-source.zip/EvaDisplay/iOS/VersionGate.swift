// Local edition: no remote policy or update gate.
import Foundation
enum PeerUpdateSignal: Equatable {
    case updateIPhone(message: String, storeURL: URL)
    case updateMac(message: String)
}
