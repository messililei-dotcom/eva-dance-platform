import Foundation

enum Brand {
    static var displayName: String { L10n.text("brand.name") }
    // Bundle identifiers, protocol IDs, Keychain service and preference domains
    // intentionally remain stable across the visible rebrand.
}
