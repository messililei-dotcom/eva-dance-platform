# 来源与修改说明

Side Display（中文：随身副屏） 是 OpenDisplay 的本地 USB / Wi-Fi 分支，遵循 GPL-3.0。

- 上游作者：Philip Poloczek。
- 本次获取的 GitHub 仓库：https://github.com/fridaybyjarvis/mac-opendisplay
- 上游项目：https://github.com/peetzweg/opendisplay
- 固定源码提交：`04590ed1871f533108d8a81f498df188c69f249c`
- 获取日期：2026-10-31。
- 本地修改：2026-10-31，Eva Display 开发分支。
- `LICENSE` 为随上游源码提供的 GPL-3.0 全文。

复用范围：Mac/ 下的虚拟显示、ScreenCaptureKit 采集、VideoToolbox 编码、USB 转发、鼠标事件及日志；iOS/ 下的视频接收、解码、渲染和触控；Shared/ 中的兼容协议。保留原有技术说明与版权归属。

本地修改包含：独立应用标识、中文窗口与设备引导、USB 回环监听、独立 Bonjour 无线发现、钥匙串配对及 TLS-PSK 加密、移除 Sparkle 自动更新与在线版本策略、原生像素镜像、输入及帧长度验证、连接状态隔离、虚拟屏幕释放修复、无需第三方构建工具的 Xcode 工程生成器，手机视口缩放与边界限制、悬浮设置、辅助功能元数据检测自动键盘、系统键盘与听写文字发送、常用按键、手机端显示模式切换，以及本机验收工具。图标使用用户确认的白底 Mac mini 与 iPhone 图案，不采用上游应用图标。

如分发此修改版，应同时提供本目录完整对应源码、构建脚本和 GPL-3.0 许可。本地原有 Eva Remote 工程不属于此分支。没有把本分支接入其云端服务，也没有改变其许可。

调研但未复制源码的方案：

- Deskreen：https://github.com/pavlobu/deskreen （AGPL-3.0，浏览器/WebRTC 接收思路）。
- LegacyPad Display：https://github.com/pedroaqs/legacypad-display （旧款 iPad 的有线屏幕方案）。

本程序不隶属 Apple 或上游作者，也不代表上游项目的官方发行。

0.4.1 新增标准中英本地化资源、运行时语言切换、稳定连接与草稿保留，以及用户确认的应用名称和 Mac mini / iPhone / iPad 白底 v4 图标。

Mac 0.4.2 删除启动时的自定义 Dock 图标覆盖，恢复系统默认图标处理。手机版本仍为 0.4.1。

0.4.3 两端图标采用用户批准的 v5（机身加高、苹果标志更明显），保留来源和完整生成提示词；Mac 继续使用系统默认 Dock 图标处理。

0.4.4 按用户要求去除当前英文品牌名称中的 Eva 前缀，改为 Side Display / Side；保留既有应用身份和历史来源记录。

2026-11-12：用户批准 v6 图标，延续原有白底、设备与蓝色箭头构图，移除 Mac mini 顶部的 Apple 标志。iOS 0.5.0 (20)、Mac 0.4.7 (15)。GPL-3.0 上游署名、许可证和完整对应源码继续保留。
