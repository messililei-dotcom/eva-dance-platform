import SwiftUI

struct DeviceSettingsView: View {
    @ObservedObject private var language = LanguageSettings.shared
    @ObservedObject var receiver: PhoneReceiver
    @ObservedObject var viewport: ViewportState
    let purchases: PurchaseStore?
    let keyboard: () -> Void
    let voice: () -> Void
    let refresh: () -> Void
    let stop: () -> Void
    @Environment(\.dismiss) private var dismiss
    @AppStorage("showAnalytics") private var showAnalytics = false
    @AppStorage("automaticKeyboard") private var automaticKeyboard = true

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Button(L10n.text("connection.refresh"), systemImage: "arrow.clockwise", action: refresh)
                        .disabled(receiver.refreshingConnection)
                        .accessibilityIdentifier("refresh-connection")
                    Text(L10n.text("connection.refreshHelp")).font(.caption).foregroundStyle(.secondary)
                }
                Section { LanguagePicker() }
                if let purchases {
                    Section {
                        PurchaseAccessView(store: purchases, connectionReady: receiver.connected && receiver.videoSize != .zero)
                    }
                }
                Section {
                    Label(receiver.connected ? L10n.format("connection.connectedTransport", receiver.connectionTransport == "WiFi" ? "Wi-Fi" : "USB") : L10n.text("等待 Mac 连接"),
                          systemImage: receiver.connectionTransport == "WiFi" ? "wifi" : "cable.connector")
                    if receiver.videoSize != .zero {
                        LabeledContent(L10n.text("传输画面"), value: "\(Int(receiver.videoSize.width)) × \(Int(receiver.videoSize.height))")
                    }
                }
                Section {
                    Toggle(L10n.text("同 Wi-Fi 无线连接"), isOn: Binding(get: { receiver.wirelessEnabled },
                                                                 set: { receiver.setWirelessEnabled($0) }))
                    Text(L10n.text(receiver.wirelessStatus)).font(.caption).foregroundStyle(.secondary)
                    if receiver.wirelessEnabled && !receiver.pairingCode.isEmpty {
                        LabeledContent(L10n.text("设备名称"), value: receiver.serviceName)
                        LabeledContent(L10n.text("配对码")) {
                            Text(receiver.pairingCode).font(.system(.caption, design: .monospaced))
                                .textSelection(.enabled)
                                .accessibilityIdentifier("wireless-pairing-code")
                        }
                        Button(L10n.text("复制配对码"), systemImage: "doc.on.doc") { UIPasteboard.general.string = receiver.pairingCode }
                        Button(L10n.text("更新配对码")) { receiver.renewPairingCode() }
                    }
                } header: { Text(L10n.text("无线连接")) } footer: {
                    Text(L10n.text("Mac 与设备连接同一 Wi-Fi。接过 USB 后可自动配对；直接无线连接时，在 Mac 输入此处配对码。更新配对码会断开无线连接，原配对需重新建立。"))
                }
                Section {
                    Picker(L10n.text("显示模式"), selection: Binding(
                        get: { receiver.activeDisplayMode ?? .extend },
                        set: { receiver.requestDisplayMode($0) })) {
                        ForEach(RemoteDisplayMode.allCases, id: \.self) { Text($0.label).tag($0) }
                    }
                    .id(language.selection)
                    .accessibilityIdentifier("display-mode-picker")
                    .disabled(!receiver.connected || !receiver.supportsModeSwitch || receiver.modeSwitchPending)
                    if receiver.modeSwitchPending { HStack { ProgressView(); Text(L10n.text("正在切换…")) } }
                } header: { Text(L10n.text("显示模式")) } footer: {
                    Text(receiver.activeDisplayMode == .mirror
                         ? L10n.text("实时屏幕显示并控制 Mac 主屏桌面。")
                         : L10n.text("扩展屏幕新增独立桌面，与 Mac 主屏同时显示不同内容。"))
                }
                Section {
                    Picker(L10n.text("画面布局"), selection: $viewport.fillViewport) {
                        Text(L10n.text("铺满屏幕")).tag(true)
                        Text(L10n.text("完整显示")).tag(false)
                    }.pickerStyle(.segmented).id(language.selection)
                    LabeledContent(L10n.text("缩放")) {
                        HStack(spacing: 12) {
                            Button(L10n.text("缩小"), systemImage: "minus.magnifyingglass") { viewport.changeZoom(to: viewport.zoom / 1.5) }
                                .labelStyle(.iconOnly).frame(minWidth: 44, minHeight: 44)
                                .disabled(viewport.zoom <= 1.005)
                            Text("\(Int(viewport.zoom * 100))%")
                                .accessibilityIdentifier("viewport-zoom-percent")
                                .monospacedDigit().frame(minWidth: 52)
                                .accessibilityLabel(L10n.format("viewport.zoomAccessibility", Int(viewport.zoom * 100), L10n.text(viewport.edgeState)))
                            Button(L10n.text("放大"), systemImage: "plus.magnifyingglass") { viewport.changeZoom(to: viewport.zoom * 1.5) }
                                .labelStyle(.iconOnly).frame(minWidth: 44, minHeight: 44)
                                .disabled(viewport.zoom >= 11.995)
                        }.buttonStyle(.borderless)
                    }
                    Toggle(isOn: $viewport.moveViewport) { Label(L10n.text("移动画面"), systemImage: "hand.draw") }
                    Button(L10n.text("画面归位"), systemImage: "arrow.up.left.and.down.right.and.arrow.up.right.and.down.left") { viewport.fit() }
                } header: { Text(L10n.text("缩放与移动")) } footer: {
                    Text(viewport.fillViewport
                         ? L10n.text("等比铺满并限制拖动边界，不露出黑边；比例不同时会裁切部分边缘。开启移动画面后，可单指拖动查看其他区域；关闭后操控 Mac。")
                         : L10n.text("完整显示会保留全部桌面，屏幕比例不一致时有留白。双指捏合可缩放，开启移动画面后可拖动查看。"))
                }
                Section {
                    Button(L10n.text("键盘输入"), systemImage: "keyboard", action: keyboard)
                        .disabled(!receiver.connected || !receiver.supportsRemoteInput)
                    Button(L10n.text("语音听写"), systemImage: "mic", action: voice)
                        .disabled(!receiver.connected || !receiver.supportsRemoteInput)
                    Toggle(L10n.text("点中输入框时自动打开键盘"), isOn: $automaticKeyboard)
                    if receiver.connected && !receiver.supportsAutomaticKeyboard { Text(L10n.text("当前 Mac 版本不支持自动识别，可先使用手动键盘。")).font(.caption).foregroundStyle(.secondary) }
                } header: { Text(L10n.text("键盘与语音")) } footer: {
                    Text(L10n.text("听写语言跟随系统键盘。使用地球键切换中文或英文键盘；界面语言不会更改键盘语言。"))
                    Text(L10n.text("自动打开需 Mac 辅助功能支持。未识别的输入框可手动打开键盘；语音使用系统键盘麦克风，编辑或听写后发送到 Mac。"))
                }
                Section(L10n.text("连接与帮助")) {
                    Toggle(L10n.text("显示性能数据"), isOn: $showAnalytics)
                    DisclosureGroup(L10n.text("操作说明")) {
                        Text(L10n.text("悬浮设置按钮可拖动，松手后吸附左右边缘，并记住位置。"))
                        Text(L10n.text("单指点击／拖动控制 Mac，双指滑动滚动；移动画面模式下，单指拖动视口。双指捏合始终用于缩放。"))
                        Text(L10n.text("USB 需信任 Mac；无线需连接同一 Wi-Fi、允许本地网络访问。两种方式均需解锁并保持程序前台。扩展屏可在 Mac 屏幕排列中调整位置。"))
                    }
                    Button(L10n.text("停止接收"), role: .destructive, action: stop)
                }
                Section {
                    Text(L10n.format("app.version", Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? ""))
                    Text(L10n.text("基于 Philip Poloczek 的 OpenDisplay，遵循 GPL-3.0。"))
                }
            }
            .navigationTitle(L10n.text("设置")).navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button(L10n.text("完成")) { dismiss() } } }
        }
    }
}
