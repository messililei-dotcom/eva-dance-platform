#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cd "$root"
python3 scripts/generate-project.py
cache="${EVA_DISPLAY_BUILD_ROOT:-$HOME/Library/Caches/EvaDisplayBuild}"
case "${1:-mac}" in
  mac)
    xcodebuild -project EvaDisplay.xcodeproj -scheme EvaDisplayMac -configuration Release \
      -derivedDataPath "$cache/mac" CODE_SIGNING_ALLOWED=NO build
    mkdir -p dist
    app="$cache/mac/Build/Products/Release/Side Display.app"
    xattr -cr "$app"
    codesign --force --sign "${EVA_DISPLAY_SIGN_IDENTITY:--}" --options runtime "$app"
    codesign --verify --deep --strict "$app"
    version=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$app/Contents/Info.plist")
    ditto --norsrc -c -k --keepParent "$app" "dist/Side-Display-$version-mac.zip"
    ;;
  simulator)
    xcodebuild -project EvaDisplay.xcodeproj -scheme EvaDisplayiOS -configuration Debug \
      -destination 'generic/platform=iOS Simulator' -derivedDataPath "$cache/simulator" CODE_SIGNING_ALLOWED=NO build
    ;;
  ios)
    xcodebuild -project EvaDisplay.xcodeproj -scheme EvaDisplayiOS -configuration Release \
      -destination 'generic/platform=iOS' -derivedDataPath "$cache/ios" CODE_SIGNING_ALLOWED=NO build
    ;;
  *) echo 'Usage: sh scripts/build.sh [mac|simulator|ios]' >&2; exit 2 ;;
esac
