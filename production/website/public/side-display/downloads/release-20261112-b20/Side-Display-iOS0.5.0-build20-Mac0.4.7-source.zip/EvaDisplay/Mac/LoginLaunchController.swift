import Foundation
import Combine
import ServiceManagement

@MainActor
final class LoginLaunchController: ObservableObject {
    static let shared = LoginLaunchController()
    @Published private(set) var status = SMAppService.mainApp.status
    @Published private(set) var failed = false
    private let configuredKey = "launchAtLoginConfigured"

    var enabled: Bool { status == .enabled || status == .requiresApproval }
    var needsApproval: Bool { status == .requiresApproval }

    func configureDefault() {
        refresh()
        guard !UserDefaults.standard.bool(forKey: configuredKey) || status == .notFound else { return }
        // Only the first run opts in. Later system/user opt-outs are respected.
        UserDefaults.standard.set(true, forKey: configuredKey)
        if status == .notRegistered || status == .notFound { setEnabled(true) }
    }

    func setEnabled(_ enabled: Bool) {
        UserDefaults.standard.set(true, forKey: configuredKey)
        failed = false
        do {
            if enabled {
                if SMAppService.mainApp.status != .enabled && SMAppService.mainApp.status != .requiresApproval {
                    try SMAppService.mainApp.register()
                }
            } else if SMAppService.mainApp.status != .notRegistered {
                try SMAppService.mainApp.unregister()
            }
        } catch {
            failed = true
            Log.info("login launch update failed: \(error.localizedDescription)")
        }
        refresh()
    }

    func refresh() {
        status = SMAppService.mainApp.status
        Log.info("login launch status: \(status.rawValue)")
    }

    func openSystemSettings() { SMAppService.openSystemSettingsLoginItems() }
}
