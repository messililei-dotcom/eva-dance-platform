// Local compatibility placeholder. Never opens automatically.
import Foundation
enum AppStore {
    static let updateURL = URL(string: "evadisplay://help")!
    static let webURL = updateURL
}
