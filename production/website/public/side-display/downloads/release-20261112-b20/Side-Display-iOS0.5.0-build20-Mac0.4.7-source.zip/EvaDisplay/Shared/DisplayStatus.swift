import Foundation

/// Translate status at render time so changing language keeps the live session.
/// Peer names, resolutions and system error details stay verbatim.
enum DisplayStatus {
    static func localized(_ value: String) -> String {
        for (prefix, key) in [
            ("Extending to ", "status.extendingTo"), ("Mirroring to ", "status.mirroringTo"),
            ("Receiving ", "status.receiving"), ("Failed: ", "status.failed"),
            ("Rotation failed: ", "status.rotationFailed"), ("Capture stopped: ", "status.captureStopped"),
            ("Listener failed: ", "status.listenerFailed")
        ] where value.hasPrefix(prefix) {
            return L10n.format(key, String(value.dropFirst(prefix.count)))
        }
        if value.contains("Screen Recording") { return L10n.text("status.screenPermission") }
        if value.hasPrefix("Extending —") { return L10n.text("status.accessibility") }
        if value.hasPrefix("Connected") { return L10n.text("status.connected") }
        if value.hasPrefix("Starting") { return L10n.text("status.starting") }
        if value.hasPrefix("Waiting for") { return L10n.text("status.waiting") }
        if value.hasPrefix("Preparing virtual") { return L10n.text("status.preparing") }
        if value.hasPrefix("Connection lost") { return L10n.text("status.retrying") }
        if value.contains("is asleep") { return L10n.text("status.sleeping") }
        if value.contains("is silent") { return L10n.text("status.silent") }
        if value == "Listener failed — restarting…" { return L10n.text("status.listenerRestarting") }
        return L10n.text(value)
    }
}
