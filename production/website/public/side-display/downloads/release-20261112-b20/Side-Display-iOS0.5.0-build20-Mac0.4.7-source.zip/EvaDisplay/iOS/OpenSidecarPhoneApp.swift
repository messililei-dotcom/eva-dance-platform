// Eva Display USB and local Wi-Fi receiver. Modified from OpenDisplay; see THIRD_PARTY.md.
import SwiftUI
import AVFoundation
import UIKit
import Combine

let deviceKind = UIDevice.current.userInterfaceIdiom == .pad ? "iPad" : "iPhone"

@main
struct EvaDisplayPhoneApp: App {
    @ObservedObject private var language = LanguageSettings.shared
    var body: some Scene { WindowGroup { ReceiverScreen().environment(\.locale, L10n.locale) } }
}

struct ReceiverScreen: View {
    @ObservedObject private var language = LanguageSettings.shared
    @StateObject private var model = ReceiverModel()
    @State private var paused = false
    @StateObject private var viewport = ViewportState()
    @State private var panel: ReceiverPanel?
    @AppStorage("automaticKeyboard") private var automaticKeyboard = true
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("showAnalytics") private var showAnalytics = false
    @AppStorage("metalRenderer") private var metalRenderer = false
    private var streaming: Bool { model.hasAccess && model.receiver.connected && model.receiver.videoSize != .zero }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if streaming {
                    Color.black.ignoresSafeArea()
                    ZoomableVideoView(displayLayer: model.receiver.displayLayer,
                                      receiver: model.receiver, useMetal: metalRenderer, viewport: viewport)
                        .id(metalRenderer)
                        .accessibilityIdentifier("remote-viewport")
                        .accessibilityValue(L10n.format("viewport.zoomAccessibility", Int(viewport.zoom * 100), L10n.text(viewport.edgeState)))
                        .ignoresSafeArea()
                    if showAnalytics {
                        VStack { Spacer(); PerfOverlay(stats: model.receiver.perf, videoSize: model.receiver.videoSize) }
                            .allowsHitTesting(false)
                    }
                } else {
                    ScrollView {
                        VStack(spacing: 24) {
                            Image(systemName: "display.2").font(.system(size: 64)).foregroundStyle(.tint).accessibilityHidden(true)
                            Text(Brand.displayName).font(.largeTitle.bold())
                            Text(L10n.format("app.deviceSubtitle", deviceKind)).font(.title3)
                            Label(paused ? L10n.text("接收已暂停") : DisplayStatus.localized(model.receiver.status), systemImage: "cable.connector")
                                .foregroundStyle(.secondary).multilineTextAlignment(.center)
                            if model.receiver.connected && model.receiver.videoSize == .zero {
                                Text(L10n.text("connection.waitingForScreenHelp"))
                                    .font(.callout).foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                                    .accessibilityIdentifier("waiting-for-screen-help")
                            }
                            Button(L10n.text("connection.refresh"), systemImage: "arrow.clockwise") {
                                paused = false; model.refreshConnection()
                            }
                            .buttonStyle(.borderedProminent).controlSize(.large)
                            .disabled(model.receiver.refreshingConnection)
                            .accessibilityIdentifier("refresh-connection")
                            VStack(alignment: .leading, spacing: 16) {
                                Label(L10n.text("在 Mac mini 上打开 Eva Display"), systemImage: "1.circle")
                                Label(L10n.text("接上 USB，或连接与 Mac 相同的 Wi-Fi"), systemImage: "2.circle")
                                Label(L10n.text("在 Mac 上允许屏幕录制"), systemImage: "3.circle")
                                Label(L10n.text("保持此程序在前台，横放设备可获得更宽桌面"), systemImage: "rectangle.landscape")
                            }.frame(maxWidth: 450, alignment: .leading).padding(24)
                                .background(.quaternary, in: RoundedRectangle(cornerRadius: 18))
                            if let purchases = model.purchases {
                                PurchaseAccessView(store: purchases,
                                                   connectionReady: model.receiver.connected && model.receiver.videoSize != .zero)
                                    .padding(24).background(.quaternary, in: RoundedRectangle(cornerRadius: 18))
                            }
                            if paused {
                                Button(L10n.text("继续接收")) { paused = false; model.sceneDidActivate() }
                                    .buttonStyle(.borderedProminent)
                            }
                            Button(L10n.text("设置与帮助"), systemImage: "gearshape") { panel = .settings }
                                .accessibilityIdentifier("receiver-settings")
                                .buttonStyle(.bordered)
                            Text(L10n.text("USB / Wi-Fi 本地传输 · 无账号 · 无服务器")).font(.footnote).foregroundStyle(.secondary)
                        }.padding(28).frame(maxWidth: .infinity)
                    }.frame(maxHeight: .infinity)
                }
            }
            .overlay {
                if streaming {
                    FloatingSettingsButton(open: { panel = .settings },
                                           refresh: { panel = nil; paused = false; model.refreshConnection() },
                                           refreshing: model.receiver.refreshingConnection)
                }
            }
            .onAppear { model.receiver.setOrientation(portrait: geo.size.height > geo.size.width) }
            .onChange(of: geo.size) { size in model.receiver.setOrientation(portrait: size.height > size.width) }
        }
        .ignoresSafeArea(.keyboard)
        .sheet(item: $panel) { kind in
            switch kind {
            case .settings:
                DeviceSettingsView(receiver: model.receiver, viewport: viewport, purchases: model.purchases,
                                   keyboard: { panel = .keyboard }, voice: { panel = .voice },
                                   refresh: { panel = nil; paused = false; model.refreshConnection() }) {
                    paused = true
                    model.receiver.shutDown()
                    panel = nil
                }.presentationDetents([.large])
            case .keyboard, .voice:
                RemoteKeyboardSheet(receiver: model.receiver, voiceHint: kind == .voice)
            }
        }
        .onChange(of: model.receiver.keyboardRequest) { _ in
            guard automaticKeyboard, streaming, panel == nil else { return }
            panel = .keyboard
        }
        .onChange(of: model.hasAccess) { allowed in
            if !allowed { panel = nil }
        }
        .alert(L10n.text("连接提示"), isPresented: Binding(get: { model.receiver.controlError != nil },
                                               set: { if !$0 { model.receiver.controlError = nil } })) {
            Button(L10n.text("知道了")) { model.receiver.controlError = nil }
        } message: { Text(L10n.text(model.receiver.controlError ?? "")) }
        .onChange(of: scenePhase) { phase in
            switch phase {
            case .active:
                if let purchases = model.purchases {
                    Task { await purchases.becameActive() }
                }
                if !paused { model.sceneDidActivate() }
            case .background: model.purchases?.checkpoint(); model.sceneDidBackground()
            case .inactive: model.purchases?.checkpoint()
            default: break
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.protectedDataWillBecomeUnavailableNotification)) { _ in model.deviceWillLock() }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.protectedDataDidBecomeAvailableNotification)) { _ in if !paused { model.deviceDidUnlock() } }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willTerminateNotification)) { _ in model.appWillTerminate() }
        .onAppear { UIApplication.shared.isIdleTimerDisabled = true; model.start() }
        .onDisappear { UIApplication.shared.isIdleTimerDisabled = false }
    }
}

private enum ReceiverPanel: String, Identifiable {
    case settings, keyboard, voice
    var id: String { rawValue }
}

struct PerfOverlay: View {
    @ObservedObject private var language = LanguageSettings.shared
    let stats: PerfStats
    let videoSize: CGSize

    var body: some View {
        VStack(spacing: 8) {
            // Metrics wrap onto extra rows when the width doesn't fit —
            // portrait iPhone is ~390pt, far less than one full row.
            FlowLayout(hSpacing: 14, vSpacing: 8) {
                // Transport badge — the question "is this cable or WiFi?"
                Text(stats.transport)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(stats.transport == "USB" ? Color.green.opacity(0.35)
                                : stats.transport == "WiFi" ? Color.blue.opacity(0.4)
                                : Color.gray.opacity(0.3),
                                in: Capsule())
                    .foregroundStyle(.white)

                if stats.e2eP50 > 0 {
                    metric("latency", String(format: "%.0f ms", stats.e2eP50))
                    metric("p95", String(format: "%.0f ms", stats.e2eP95))
                    metric("encode", String(format: "%.0f ms", stats.encodeP50))
                }
                if stats.decodeP50 > 0 {
                    metric("decode", String(format: "%.1f ms", stats.decodeP50))
                }
                if stats.photonP50 > 0 {
                    // True capture→glass latency (Metal presented handler) —
                    // the only number that includes display vsync.
                    metric("photon", String(format: "%.0f ms", stats.photonP50))
                }
                if stats.inputP50 > 0 {
                    // touch→CGEvent on the Mac; full touch-to-photon adds
                    // the render+capture wait and one e2e on top.
                    metric("input", String(format: "%.0f ms", stats.inputP50))
                }
                metric("rtt", String(format: "%.0f ms", stats.rttMs))
                metric("FPS", "\(stats.fps)")
                if stats.capFps > 0 {
                    metric("Mac cap", "\(stats.capFps)")
                }
                metric("Mbit/s", String(format: "%.1f", stats.mbps))
                metric("stalls", "\(stats.stalls)")
                metric("enc↓", "\(stats.macEncDrops)")
                metric("net↓", "\(stats.macNetDrops)")
                if stats.macPending > 0 {
                    metric("queue", "\(stats.macPending)")
                }
                if stats.decodeFlushes > 0 {
                    metric("flushes", "\(stats.decodeFlushes)")
                }
                metric("res", "\(Int(videoSize.width))×\(Int(videoSize.height))")
            }
            // Two graphs side by side where they fit (landscape), stacked
            // where they don't (portrait).
            ViewThatFits(in: .horizontal) {
                HStack(spacing: 14) { graphs }
                VStack(spacing: 8) { graphs }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 9)
        .background(.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal, 8)
    }

    @ViewBuilder
    private var graphs: some View {
        graph("latency ms (cap→display)",
              BarGraph(samples: stats.e2eSamples, ceiling: 80,
                       good: 25, warn: 40, reference: nil))
        graph("frame interval ms",
              BarGraph(samples: stats.samples, ceiling: 60,
                       good: 25, warn: 50, reference: 16.7))
    }

    private func metric(_ label: String, _ value: String) -> some View {
        VStack(spacing: 1) {
            Text(value)
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white)
            Text(L10n.text(label))
                .font(.system(size: 8, design: .monospaced))
                .foregroundStyle(.white.opacity(0.5))
        }
    }

    private func graph(_ label: String, _ content: BarGraph) -> some View {
        VStack(spacing: 2) {
            content.frame(width: 220, height: 38)
            Text(L10n.text(label))
                .font(.system(size: 8, design: .monospaced))
                .foregroundStyle(.white.opacity(0.5))
        }
    }
}

/// Left-aligned wrapping row: children flow onto as many rows as the
/// proposed width requires. Keeps the perf overlay inside the screen in
/// portrait instead of clipping off both edges.
struct FlowLayout: Layout {
    var hSpacing: CGFloat = 14
    var vSpacing: CGFloat = 8
    var constrainWidth = false

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews,
                      cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0
        var rowHeight: CGFloat = 0, width: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(constrainWidth ? ProposedViewSize(width: maxWidth, height: nil) : .unspecified)
            if x > 0, x + size.width > maxWidth {
                x = 0
                y += rowHeight + vSpacing
                rowHeight = 0
            }
            x += size.width + hSpacing
            rowHeight = max(rowHeight, size.height)
            width = max(width, x - hSpacing)
        }
        return CGSize(width: width, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize,
                       subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY
        var rowHeight: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(constrainWidth ? ProposedViewSize(width: bounds.width, height: nil) : .unspecified)
            if x > bounds.minX, x + size.width > bounds.maxX {
                x = bounds.minX
                y += rowHeight + vSpacing
                rowHeight = 0
            }
            subview.place(at: CGPoint(x: x, y: y),
                          proposal: constrainWidth ? ProposedViewSize(size) : .unspecified)
            x += size.width + hSpacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}

/// Bar graph over a rolling sample window with green/yellow/red thresholds
/// and an optional reference line (e.g. 16.7 ms = 60 fps).
struct BarGraph: View {
    let samples: [Double]
    let ceiling: Double
    let good: Double
    let warn: Double
    let reference: Double?

    var body: some View {
        Canvas { context, size in
            guard !samples.isEmpty else { return }
            let barWidth = size.width / CGFloat(max(samples.count, 1))
            for (i, ms) in samples.enumerated() {
                let h = min(ms / ceiling, 1.0) * size.height
                let rect = CGRect(x: CGFloat(i) * barWidth,
                                  y: size.height - h,
                                  width: max(barWidth - 0.5, 0.5),
                                  height: h)
                let color: Color = ms <= good ? .green : ms <= warn ? .yellow : .red
                context.fill(Path(rect), with: .color(color.opacity(0.85)))
            }
            if let reference {
                let y = size.height - (reference / ceiling) * size.height
                context.stroke(Path { p in
                    p.move(to: CGPoint(x: 0, y: y))
                    p.addLine(to: CGPoint(x: size.width, y: y))
                }, with: .color(.white.opacity(0.35)), lineWidth: 0.5)
            }
        }
    }
}

// MARK: - Settings / help sheet

@MainActor
final class ReceiverModel: ObservableObject {
    let receiver: PhoneReceiver
    let purchases: PurchaseStore?
    var hasAccess: Bool { purchases?.hasAccess ?? true }
    private var started = false
    private var cancellables = Set<AnyCancellable>()

    init() {
        #if SIDE_DISPLAY_COMMERCE
        let store: PurchaseStore? = PurchaseStore()
        #else
        let store: PurchaseStore? = nil
        #endif
        purchases = store
        let accessGate = store?.gate ?? RemoteAccessGate()
        if store == nil { accessGate.setAllowed(true) }
        receiver = PhoneReceiver(displayLayer: AVSampleBufferDisplayLayer(), accessGate: accessGate)
        // Announce the native panel size to the Mac.
        let native = UIScreen.main.nativeBounds.size   // portrait pixels
        receiver.setNativePanel(long: Int(max(native.width, native.height)),
                                short: Int(min(native.width, native.height)),
                                scale: Double(UIScreen.main.nativeScale))
        let savedName = UserDefaults.standard.string(forKey: "deviceName")
        receiver.serviceName = (savedName?.isEmpty == false) ? savedName! : UIDevice.current.name
        receiver.objectWillChange
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in self?.objectWillChange.send() }
            .store(in: &cancellables)
        if let store {
            store.objectWillChange
                .receive(on: DispatchQueue.main)
                .sink { [weak self] _ in self?.objectWillChange.send() }
                .store(in: &cancellables)
            store.$state.removeDuplicates().sink { [weak self] state in
                self?.receiver.updateAccess(state.permitsAccess)
            }.store(in: &cancellables)
        }
    }

    func start() {
        guard !started else { return }
        started = true
        purchases?.start()
        receiver.start(port: 9000)
    }

    // MARK: - Lock vs app switch vs app quit

    // A plain app switch keeps the session (and the Mac's virtual display,
    // and therefore the user's window arrangement) alive INDEFINITELY. The
    // assertion buys ~30s of live pings; after iOS suspends us the kernel
    // still accepts the Mac's redials, so the session survives untouched
    // until we return. Only a device lock (deliberate "screen off") or the
    // app being quit ends the session. Known hole: a lock that happens
    // after we're already suspended is undetectable — no code runs and the
    // kernel behaves identically — so the display stays up until the user
    // returns or the app dies.
    private var backgroundToken: UIBackgroundTaskIdentifier = .invalid

    func sceneDidBackground() {
        // Known limitation: lock detection rides the protected-data signal,
        // which only fires when a passcode is set AND "Require Passcode" is
        // Immediately (the Face ID default). Other configurations make a
        // lock indistinguishable from an app switch, so those keep the
        // session like a backgrounded app would.
        if !UIApplication.shared.isProtectedDataAvailable {
            // Backgrounded because the device locked, not an app switch.
            Log.info("backgrounded by device lock — sleeping now")
            goToSleep()
            return
        }
        Log.info("app switched away — keeping the session, rendering paused")
        beginBackgroundAssertion()
        receiver.setRenderingPaused(true)
    }

    func sceneDidActivate() {
        // Recheck elapsed trial time before resuming any queued video/input.
        purchases?.checkpoint()
        endBackgroundAssertion()
        receiver.setRenderingPaused(false)
        receiver.ensureListening()
    }

    func refreshConnection() {
        purchases?.checkpoint()
        endBackgroundAssertion()
        receiver.setRenderingPaused(false)
        receiver.refreshConnection()
    }

    func deviceWillLock() {
        Log.info("device locking — sleeping now")
        goToSleep()
    }

    /// Unlock arrives via the protected-data notification, which also fires
    /// when the user unlocks into ANOTHER app while we sit in the background
    /// — don't re-arm the listener or unpause rendering off-screen there;
    /// the real return still comes through scenePhase.
    func deviceDidUnlock() {
        guard UIApplication.shared.applicationState == .active else {
            Log.info("unlocked while backgrounded — staying dormant")
            return
        }
        sceneDidActivate()
    }

    /// User swiped the app away (or iOS terminates us while still running):
    /// ~5s of runtime remain, plenty for the "closing" goodbye that lets the
    /// Mac end the session immediately instead of after its silence grace.
    func appWillTerminate() {
        Log.info("app terminating — closing session")
        receiver.shutDown()
    }

    private func goToSleep() {
        receiver.enterSleep { [weak self] in
            DispatchQueue.main.async { self?.endBackgroundAssertion() }
        }
    }

    private func beginBackgroundAssertion() {
        guard backgroundToken == .invalid else { return }
        backgroundToken = UIApplication.shared.beginBackgroundTask { [weak self] in
            // Suspension takes us now; the session stays up by design (the
            // kernel keeps accepting for us) — just release the assertion.
            self?.endBackgroundAssertion()
        }
    }

    private func endBackgroundAssertion() {
        guard backgroundToken != .invalid else { return }
        UIApplication.shared.endBackgroundTask(backgroundToken)
        backgroundToken = .invalid
    }
}

// MARK: - Video layer host view

/// UIView whose backing layer is the AVSampleBufferDisplayLayer.
/// Forwards touches as normalized video-space coordinates (touchscreen mode).
struct VideoLayerView: UIViewRepresentable {
    let displayLayer: AVSampleBufferDisplayLayer
    let receiver: PhoneReceiver
    let useMetal: Bool

    func makeUIView(context: Context) -> VideoView {
        Self.makeVideoView(displayLayer: displayLayer, receiver: receiver, useMetal: useMetal)
    }

    static func makeVideoView(displayLayer: AVSampleBufferDisplayLayer, receiver: PhoneReceiver, useMetal: Bool) -> VideoView {
        let view = VideoView()
        view.backgroundColor = .black
        view.isMultipleTouchEnabled = true
        view.receiver = receiver

        Log.info("video view: metal=\(useMetal)")
        if useMetal, let renderer = MetalVideoRenderer() {
            Log.info("metal renderer active")
            view.metalRenderer = renderer
            view.layer.addSublayer(renderer.metalLayer)
            receiver.onDecodedFrame = { [weak renderer] pixelBuffer, captureMs in
                renderer?.render(pixelBuffer, captureMs: captureMs)
            }
            renderer.onPresented = { [weak receiver] presentedTime, captureMs in
                receiver?.recordPresented(presentedTime: presentedTime, captureMs: captureMs)
            }
        } else {
            receiver.onDecodedFrame = nil   // route frames back to AVSBDL
            displayLayer.frame = view.bounds
            view.layer.addSublayer(displayLayer)
        }

        let pan = UIPanGestureRecognizer(target: view, action: #selector(VideoView.didTwoFingerPan(_:)))
        pan.minimumNumberOfTouches = 2
        pan.maximumNumberOfTouches = 2
        pan.delegate = view
        view.addGestureRecognizer(pan)

        // Local cursor echo: position updates ride the ~2ms control path
        // instead of the ~30ms video path, so the pointer feels native.
        receiver.onCursor = { [weak view] x, y, visible in
            view?.moveCursor(x: x, y: y, visible: visible)
        }
        receiver.onCursorImage = { [weak view] image, anchor, normSize in
            view?.setCursorSprite(image, anchor: anchor, normSize: normSize)
        }
        return view
    }

    func updateUIView(_ uiView: VideoView, context: Context) {
        // videoSize arrives after the format description — re-fit the layers.
        uiView.setNeedsLayout()
    }

    final class VideoView: UIView, UIGestureRecognizerDelegate {
        weak var receiver: PhoneReceiver?
        var remoteGesturesSuspended = false
        func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            otherGestureRecognizer is UIPinchGestureRecognizer
        }
        func cancelRemoteGesture() {
            if downSent { receiver?.sendTouch(phase: "cancelled", x: lastNorm.x, y: lastNorm.y) }
            discardPendingDown()
            twoFingerActive = false
        }
        var metalRenderer: MetalVideoRenderer?

        private let cursorLayer: CALayer = {
            let layer = CALayer()
            layer.isHidden = true
            layer.zPosition = 10
            // Position updates arrive at 120Hz — implicit animations would
            // smear the cursor behind every move.
            layer.actions = ["position": NSNull(), "contents": NSNull(),
                             "bounds": NSNull(), "hidden": NSNull()]
            return layer
        }()
        private var cursorNormSize = CGSize.zero
        private var cursorNorm = CGPoint(x: 0.5, y: 0.5)
        private var cursorVisible = false

        private var lastLoggedLayout = ""

        override func layoutSubviews() {
            super.layoutSubviews()
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            if let renderer = metalRenderer {
                // The metal layer scales its drawable to fill its frame, so
                // the frame itself must be the aspect-fit rect.
                renderer.metalLayer.frame = videoRect() ?? bounds
            } else {
                // AVSBDL aspect-fits internally (videoGravity) — full bounds.
                layer.sublayers?.first?.frame = bounds
            }
            if cursorLayer.superlayer == nil { layer.addSublayer(cursorLayer) }
            updateCursorLayout()
            CATransaction.commit()
            // Rotation diagnostics — one line per layout change.
            let video = receiver?.videoSize ?? .zero
            let line = "layout: bounds=\(Int(bounds.width))x\(Int(bounds.height))"
                + " video=\(Int(video.width))x\(Int(video.height))"
                + " layer=\(Int(layer.sublayers?.first?.frame.width ?? -1))x\(Int(layer.sublayers?.first?.frame.height ?? -1))"
            if line != lastLoggedLayout {
                lastLoggedLayout = line
                Log.info(line)
            }
        }

        /// Aspect-fit rect of the video inside the view (inverse of normalized()).
        private func videoRect() -> CGRect? {
            guard let video = receiver?.videoSize, video != .zero,
                  bounds.width > 0, bounds.height > 0 else { return nil }
            let scale = min(bounds.width / video.width, bounds.height / video.height)
            let size = CGSize(width: video.width * scale, height: video.height * scale)
            return CGRect(x: (bounds.width - size.width) / 2,
                          y: (bounds.height - size.height) / 2,
                          width: size.width, height: size.height)
        }

        func moveCursor(x: Double, y: Double, visible: Bool) {
            cursorNorm = CGPoint(x: x, y: y)
            cursorVisible = visible
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            cursorLayer.isHidden = !visible || cursorLayer.contents == nil
            updateCursorLayout()
            CATransaction.commit()
        }

        func setCursorSprite(_ image: UIImage, anchor: CGPoint, normSize: CGSize) {
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            cursorLayer.contents = image.cgImage
            cursorLayer.anchorPoint = anchor
            cursorNormSize = normSize
            cursorLayer.isHidden = !cursorVisible
            updateCursorLayout()
            CATransaction.commit()
        }

        private func updateCursorLayout() {
            guard let rect = videoRect(), cursorNormSize != .zero else { return }
            cursorLayer.bounds = CGRect(x: 0, y: 0,
                                        width: cursorNormSize.width * rect.width,
                                        height: cursorNormSize.height * rect.height)
            cursorLayer.position = CGPoint(x: rect.minX + cursorNorm.x * rect.width,
                                           y: rect.minY + cursorNorm.y * rect.height)
        }

        // The video is aspect-fit inside the view; map view coords into the
        // displayed video rect and normalize to [0,1].
        private func normalized(_ point: CGPoint) -> (x: Double, y: Double)? {
            guard let video = receiver?.videoSize, video != .zero,
                  bounds.width > 0, bounds.height > 0 else { return nil }
            let scale = min(bounds.width / video.width, bounds.height / video.height)
            let size = CGSize(width: video.width * scale, height: video.height * scale)
            let origin = CGPoint(x: (bounds.width - size.width) / 2,
                                 y: (bounds.height - size.height) / 2)
            let x = (point.x - origin.x) / size.width
            let y = (point.y - origin.y) / size.height
            return (min(max(x, 0), 1), min(max(y, 0), 1))
        }

        private var twoFingerActive = false
        private var lastPan = CGPoint.zero
        private var lastNorm: (x: Double, y: Double) = (0.5, 0.5)

        @objc func didTwoFingerPan(_ recognizer: UIPanGestureRecognizer) {
            guard !remoteGesturesSuspended else { return }
            guard let video = receiver?.videoSize, video != .zero else { return }
            switch recognizer.state {
            case .began:
                twoFingerActive = true
                lastPan = .zero
                // macOS delivers scroll to whatever sits under the cursor, and
                // the cursor no longer follows the fingers now that a press is
                // withheld until it commits. Put it on the gesture once, up
                // front, so the scroll lands on the window being touched. Once
                // only: a real trackpad does not drag the cursor while
                // scrolling, and moving it mid-gesture would change the target.
                if let n = normalized(recognizer.location(in: self)) {
                    lastNorm = n
                    receiver?.sendTouch(phase: "moved", x: n.x, y: n.y)
                }
            case .changed:
                let t = recognizer.translation(in: self)
                let scale = min(bounds.width / video.width, bounds.height / video.height)
                // Deltas in video pixels, natural-scrolling direction.
                receiver?.sendScroll(dx: (t.x - lastPan.x) / scale,
                                     dy: (t.y - lastPan.y) / scale)
                lastPan = t
            default:
                twoFingerActive = false
            }
        }

        // A press is only a click once we know a second finger is not coming.
        // Sending `began` on contact posted a mouse-down we then had to take
        // back, and taking it back only works when UIKit happens to deliver
        // `cancelled`; when the pan recognizer misses and we get a plain
        // `ended` instead, that down/up pair *is* a click, which is why every
        // other two-finger scroll opened whatever sat under the first finger.
        // So hold the down until the gesture commits to being one.
        private var pendingDown: (x: Double, y: Double)?
        private var downSent = false
        private var holdTimer: DispatchWorkItem?

        /// Movement (in points) that turns a held press into a drag.
        private let dragSlop: CGFloat = 10
        /// A press this long with no second finger is a deliberate hold, so
        /// commit it: press-and-hold menus and drag handles need the button.
        private let holdDelay: TimeInterval = 0.12
        private var pendingDownPoint: CGPoint = .zero

        /// Emit the withheld `began`, at the point the finger first landed so a
        /// drag starts where the user touched rather than where slop was crossed.
        private func commitPendingDown() {
            guard let p = pendingDown, !downSent else { return }
            downSent = true
            holdTimer?.cancel()
            holdTimer = nil
            receiver?.sendTouch(phase: "began", x: p.x, y: p.y)
        }

        /// Drop the press without a trace. Nothing reached the Mac, so there is
        /// no button to release and no click to suppress.
        private func discardPendingDown() {
            pendingDown = nil
            downSent = false
            holdTimer?.cancel()
            holdTimer = nil
        }

        private func send(_ phase: String, _ touches: Set<UITouch>, _ event: UIEvent?) {
            guard !remoteGesturesSuspended else { cancelRemoteGesture(); return }
            // Ignore single-finger events while a two-finger gesture runs,
            // and end the click if a second finger joins mid-press.
            if twoFingerActive || (event?.allTouches?.count ?? 1) > 1 {
                if downSent {
                    receiver?.sendTouch(phase: "cancelled", x: lastNorm.x, y: lastNorm.y)
                }
                discardPendingDown()
                return
            }
            guard let touch = touches.first,
                  let norm = normalized(touch.location(in: self)) else { return }
            lastNorm = norm

            switch phase {
            case "began":
                let location = touch.location(in: self)
                pendingDown = norm
                pendingDownPoint = location
                downSent = false
                let work = DispatchWorkItem { [weak self] in self?.commitPendingDown() }
                holdTimer = work
                DispatchQueue.main.asyncAfter(deadline: .now() + holdDelay, execute: work)
                return
            case "ended":
                // A tap: nothing was posted yet, so post the whole click now.
                if pendingDown != nil, !downSent { commitPendingDown() }
                // No down means the press was already discarded (a second
                // finger took it), so there is nothing to release.
                if downSent { receiver?.sendTouch(phase: "ended", x: norm.x, y: norm.y) }
                discardPendingDown()
                return
            case "cancelled":
                if downSent {
                    receiver?.sendTouch(phase: "cancelled", x: norm.x, y: norm.y)
                }
                discardPendingDown()
                return
            case "moved":
                if pendingDown != nil, !downSent {
                    let moved = hypot(touch.location(in: self).x - pendingDownPoint.x,
                                      touch.location(in: self).y - pendingDownPoint.y)
                    // Below slop the finger is still deciding: track the cursor
                    // (the Mac turns a move without a down into mouseMoved) but
                    // keep the button up so a second finger can still cancel.
                    if moved > dragSlop { commitPendingDown() }
                }
            default:
                break
            }

            if phase == "moved", let event {
                // The panel samples touches at 120Hz but UIKit delivers at
                // display refresh — forward every coalesced sample so the Mac
                // gets the full-rate drag, then UIKit's predicted touch so the
                // cursor leads toward where the finger will be (~1 frame of
                // perceived latency back; corrected by the next real sample).
                for t in event.coalescedTouches(for: touch) ?? [touch] {
                    if let n = normalized(t.location(in: self)) {
                        lastNorm = n
                        receiver?.sendTouch(phase: "moved", x: n.x, y: n.y)
                    }
                }
                if let predicted = event.predictedTouches(for: touch)?.last,
                   let n = normalized(predicted.location(in: self)) {
                    receiver?.sendTouch(phase: "moved", x: n.x, y: n.y)
                }
                return
            }
            receiver?.sendTouch(phase: phase, x: norm.x, y: norm.y)
        }

        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) { send("began", touches, event) }
        override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) { send("moved", touches, event) }
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { send("ended", touches, event) }
        override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { send("cancelled", touches, event) }
    }
}
