# Corresponding source

Side Display iOS 0.5.0 (20) and macOS 0.4.7 (15), 2026-11-12.

GPL-3.0: see LICENSE and THIRD_PARTY.md for Philip Poloczek / OpenDisplay attribution and modifications. This archive includes the full production source, localized resources, approved v6 icon inputs, and build scripts. No private signing keys or credentials are required to inspect or compile it.

Build with Xcode 27.2 (used for these releases) and Python 3:

    python3 scripts/generate-project.py
    sh scripts/build.sh simulator
    sh scripts/build.sh mac

Use your own Apple Developer team/certificates for device or distribution signing. iOS 16+ and macOS 14+ deployment targets. The default generated project is free and omits UI-test targets. Optional commerce code is not enabled in the release.

The macOS virtual-display implementation is separate from the iOS app. No external package download is needed for the production Xcode project. App Store availability is separate from this source release.
