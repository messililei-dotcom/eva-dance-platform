#!/usr/bin/env python3
"""Package the approved icon into native asset sizes; no visual redesign."""
from pathlib import Path
import json
import subprocess

root = Path(__file__).resolve().parent.parent
source = root / 'design/icon-proposals/side-display-white-no-apple-v6.png'

def image(folder, name, pixels):
    subprocess.run(['sips', '-z', str(pixels), str(pixels), str(source), '--out', str(folder / name)],
                   check=True, stdout=subprocess.DEVNULL)

for platform in ['Mac', 'iOS']:
    folder = root / platform / 'Assets.xcassets/AppIcon.appiconset'
    images = []
    if platform == 'Mac':
        for size in [16, 32, 128, 256, 512]:
            for scale in [1, 2]:
                name = f'icon_{size}@{scale}x.png'
                image(folder, name, size * scale)
                images.append(dict(filename=name, idiom='mac', size=f'{size}x{size}', scale=f'{scale}x'))
    else:
        for idiom, sizes, scales in [('iphone', [20, 29, 40, 60], [2, 3]),
                                      ('ipad', [20, 29, 40, 76], [1, 2])]:
            for size in sizes:
                for scale in scales:
                    name = f'{idiom}_{size}@{scale}x.png'
                    image(folder, name, size * scale)
                    images.append(dict(filename=name, idiom=idiom, size=f'{size}x{size}', scale=f'{scale}x'))
        image(folder, 'ipad_83.5@2x.png', 167)
        images.append(dict(filename='ipad_83.5@2x.png', idiom='ipad', size='83.5x83.5', scale='2x'))
        image(folder, 'icon.png', 1024)
        images.append(dict(filename='icon.png', idiom='ios-marketing', size='1024x1024', scale='1x'))
    (folder / 'Contents.json').write_text(json.dumps(dict(images=images, info=dict(author='xcode', version=1)), indent=2) + '\n')
print('Prepared approved white no-Apple-mark icon: Mac 10 sizes; iPhone/iPad/marketing 18 sizes.')
