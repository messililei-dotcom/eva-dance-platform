# Side Display — iOS 0.5.0 candidate

Current source candidates: iOS 0.5.0 (20) and Mac 0.4.7 (15). Both apps are free, with unlimited mirroring, extended display and remote controls. The approved white device-and-arrow icon omits the Apple mark. See the [product website](https://www.swod.com.cn/side-display/release-0.5.0-en.html) and App Store for release availability.

Product introduction with features, setup instructions and actual software screenshots: [English](release/apple-review-20261101/product/PRODUCT.en.md) · [简体中文](release/apple-review-20261101/product/PRODUCT.zh-Hans.md).

**Turn your iPhone or iPad into a second display for your Mac.**

Extend your desktop or mirror your main screen over USB or an encrypted local Wi-Fi connection. Control your Mac with touch, pinch to zoom, and use the native keyboard or system dictation.

[简体中文](README.md)

Version 0.4.4 removes the Eva prefix: full name Side Display, icon label Side, Chinese name 随身副屏. Both the Mac and connected iPhone have been updated in place, preserving app identity and pairing.

Version 0.4.3 updates both apps to the user-approved icon with a taller Mac mini enclosure and a more prominent Apple mark. The default macOS rounded icon path from 0.4.2 is preserved. See the [icon update](ICON-0.4.3.md) and [Dock fix](MAC-ICON-0.4.2.md).

## Requirements

- Mac running macOS 14 or later, with a signed-in desktop session.
- iPhone or iPad running iOS/iPadOS 16 or later.
- USB data cable, or both devices on the same local network. Your Mac may use Ethernet on the same router.
- Keep the receiving app open and the mobile device unlocked.
- Screen Recording permission on the Mac; Accessibility permission for touch and keyboard control.

## Connect

1. Open **Side Display.app** on your Mac.
2. Open **Side / 随身副屏** on your iPhone or iPad.
3. USB: connect a data cable and trust your Mac. This also saves a Wi-Fi pairing automatically.
4. Wi-Fi: allow Local Network access on both devices. Select your device on the Mac. For first-time wireless pairing, enter the code from **Settings → Wireless Connection** on the receiver.
5. Choose **Extended Display** for an independent desktop, or **Mirror Screen** to show the main desktop live. Use **Arrange Displays** on the Mac to position the extended screen.

After USB pairing, unplugging the cable switches to Wi-Fi when the device’s wireless service is available. Reconnecting the cable prioritizes USB. No cloud account or relay server is used.

## Touch, keyboard and dictation

Tap or drag with one finger to control your Mac. Swipe with two fingers to scroll. Pinch to zoom. In Settings, enable **Pan Screen** to move around the enlarged view, then disable it to control your Mac again.

Tap a text field on the Mac’s screen to open the compact native input bar, or open **Keyboard** from Settings. Text stays in the draft until you tap the send arrow. Additional keys are available in **More Keys**.

Dictation uses the microphone on the system keyboard. Use the globe key to choose an English or Chinese keyboard. The interface language does not change the keyboard or translate entered text. System dictation availability follows your device settings.

## Languages

Both apps support **English**, **简体中文**, and **System Default** in **语言 / Language**. The first supported language in your system preference list is used; unsupported language lists fall back to English. You can switch the interface without restarting the connection. Drafts are retained when closing and reopening the input panel.

Native Home Screen/Finder names and system permission dialogs follow the operating system’s app-language settings. English uses the full product name **Side Display** inside the app and the short icon label **Side**; Simplified Chinese uses **随身副屏**.

## Current build and verification

This is a signed local development build, not an App Store release or a notarized public Mac distribution. The iPhone 14 Pro Max has passed USB, Wi-Fi, desktop control, keyboard and previous compact-input acceptance. English/Chinese live switching has been exercised on iPhone and iPad simulators. The physical iPhone user also confirmed the new name, icon and live language switching with the connection retained. Real iPad, older OS versions and simultaneous physical devices remain unverified.

Native 5120×2880 mirroring is supported on the tested Mac. Frame rate varies with capture, encoding, network and content. Choose Balanced or Fast quality to reduce traffic. This app does not replace a physical display for FileVault, boot/login screens or recovery mode.

The rebrand preserves bundle identifiers, pairing credentials and preferences. Technical project/target names remain unchanged to preserve compatibility.

## Build and source

Open `EvaDisplay.xcodeproj`, or run:

```sh
python3 scripts/generate-project.py
sh scripts/build.sh mac
sh scripts/install-device.sh DEVICE_UDID APPLE_TEAM_ID
sh scripts/test-localization.sh
```

A physical iOS installation requires your own Apple development signing account and Developer Mode. Build caches default to `~/Library/Caches/EvaDisplayBuild`. The Mac archive and corresponding source are under `dist/`. The source archive includes the approved icon master and packaging script.

Side Display is based on [OpenDisplay](https://github.com/peetzweg/opendisplay), licensed under GPL-3.0. See [LICENSE](LICENSE) and [THIRD_PARTY.md](THIRD_PARTY.md).

主动刷新连接 / Manual connection refresh: [实现与验证](REFRESH-CONNECTION.md)。
