// PhoneReceiver — Milestone 1: receive H.264 over TCP and display it.
//
// Pipeline:  TCP socket -> deframe -> Annex B parse -> CMSampleBuffer
//            -> AVSampleBufferDisplayLayer (decodes + renders)
//
// The phone LISTENS; the Mac connects (required for usbmux/USB).
// Wire protocol: [4-byte big-endian length][Annex B payload].

import Foundation
import Network
import AVFoundation
import CoreMedia
import VideoToolbox
import UIKit

/// One-second window of pipeline health, plus per-frame timing samples for
/// the performance overlay graph.
struct PerfStats: Equatable {
    var fps = 0
    var mbps = 0.0
    var avgFrameMs = 0.0
    var maxFrameMs = 0.0
    var stalls = 0               // frames that arrived >50ms late (this window)
    var decodeFlushes = 0        // display layer failures since connect
    var samples: [Double] = []   // last ~120 inter-frame intervals, ms
    // True end-to-end latency (Mac capture → phone display handoff), using
    // the clock offset estimated from timestamped ping/pong.
    var e2eP50 = 0.0
    var e2eP95 = 0.0
    var encodeP50 = 0.0          // Mac-side capture→socket (encode + queue)
    var rttMs = 0.0              // control-channel round trip
    var e2eSamples: [Double] = []  // last ~120 per-frame e2e latencies, ms
    var transport = "—"          // USB (loopback via usbmux) or WiFi
    var macDrops = 0             // enc + net drops (legacy total)
    var macEncDrops = 0          // Mac skipped capture: encoder busy
    var macNetDrops = 0          // Mac skipped capture: TCP queue full
    var macPending = 0           // Mac send queue depth right now
    var inputP50 = 0.0           // touch sent → CGEvent injected on the Mac, ms
    var inputP95 = 0.0
    var capFps = 0               // frames ScreenCaptureKit delivered on the Mac
    // Metal renderer path only:
    var decodeP50 = 0.0          // VTDecompressionSession decode, ms
    var photonP50 = 0.0          // Mac capture → frame actually on glass, ms
    var photonP95 = 0.0
}

final class PhoneReceiver: ObservableObject {
    @Published private(set) var refreshingConnection = false
    @Published var wirelessEnabled = UserDefaults.standard.object(forKey: "wirelessEnabled") == nil || UserDefaults.standard.bool(forKey: "wirelessEnabled")
    @Published private(set) var pairingCode = ""
    @Published private(set) var wirelessStatus = "正在准备无线连接"
    @Published private(set) var connectionTransport = "—"
    private var wirelessListener: NWListener?
    private var pendingWireless: [ObjectIdentifier: NWConnection] = [:]
    private var wirelessCode: String?

    @Published var activeDisplayMode: RemoteDisplayMode?
    @Published var supportsRemoteInput = false
    @Published var supportsModeSwitch = false
    @Published var supportsAutomaticKeyboard = false
    @Published var keyboardDraft = ""
    @Published var keyboardRequest = 0
    @Published var modeSwitchPending = false
    @Published var controlError: String?
    private var requestedMode: RemoteDisplayMode?
    private var modeRequestGeneration = 0

    @Published var status = "Starting…"
    @Published var fps = 0
    @Published var connected = false
    @Published var videoSize = CGSize.zero   // for touch coordinate mapping
    @Published var perf = PerfStats()
    // Compatibility signal from the connected Mac (issue #132). Nil = no signal.
    // Merged into the update gate by ReceiverScreen.
    @Published var peerSignal: PeerUpdateSignal?

    private var listener: NWListener?
    private var listenerHealthy = false
    private var listenerRestartGeneration = 0
    private var connection: NWConnection?
    private let queue = DispatchQueue(label: "receiver.video")
    private var buffer = Data()
    private var formatDesc: CMVideoFormatDescription?
    private var sps: Data?
    private var pps: Data?

    // Liveness: the Mac streams video and pings every 2s; if nothing arrives
    // for 5s the connection is half-open (Mac killed, tunnel died) — drop it
    // so the listener can accept a fresh one.
    private var lastDataReceived = Date()
    private var port: UInt16 = 9000
    private var monitorsStarted = false

    private var framesThisWindow = 0
    private var fpsWindowStart = Date()
    private var bytesThisWindow = 0
    private var stallsThisWindow = 0
    private var decodeFlushes = 0
    private var lastFrameAt: Date?
    private var frameIntervals: [Double] = []   // ring buffer, ms
    private let maxSamples = 120

    // Clock sync (NTP-style): offset = macClock − phoneClock, taken from the
    // ping/pong sample with the lowest RTT (least asymmetric).
    private var offsetSamples: [(rtt: Double, offset: Double)] = []
    private var clockOffsetMs: Double?
    private var lastRttMs = 0.0
    private var e2eWindow: [Double] = []        // capture→display, ms
    private var encodeWindow: [Double] = []     // capture→socket on the Mac, ms
    private var e2eRing: [Double] = []          // per-frame, for the overlay graph
    private var statsReportCounter = 0
    private var transport = "—"
    private var macDrops = 0
    private var macEncDrops = 0
    private var macNetDrops = 0
    private var macPending = 0
    private var macInputP50 = 0.0
    private var macInputP95 = 0.0
    private var macCapFps = 0

    private var nowMs: Double { Date().timeIntervalSince1970 * 1000 }

    // Local cursor echo (both called on the main thread): position is
    // normalized [0,1] in video space; the sprite arrives as a PNG with its
    // hotspot anchor and size normalized against the Mac display.
    var onCursor: ((_ x: Double, _ y: Double, _ visible: Bool) -> Void)?
    var onCursorImage: ((_ image: UIImage, _ anchor: CGPoint, _ normSize: CGSize) -> Void)?

    // Metal renderer path (experimental, "metalRenderer" setting): we decode
    // explicitly and hand BGRA buffers out; called on the receiver queue.
    var onDecodedFrame: ((_ pixelBuffer: CVPixelBuffer, _ captureMs: Double?) -> Void)?
    private var decompressionSession: VTDecompressionSession?
    private var decodeWindow: [Double] = []
    private var photonWindow: [Double] = []
    private var loggedDisplayPath = false
    private var decodeErrorCount = 0
    // Default OFF: A/B measurement showed the system video layer reaches
    // glass faster than our CAMetalLayer path (iOS gives AVSBDL a dedicated
    // compositor plane). Kept as an experimental toggle + for its metrics.
    private var useMetalPath: Bool { UserDefaults.standard.bool(forKey: "metalRenderer") }

    /// Called by the renderer's presented handler: maps the CACurrentMediaTime-
    /// based glass timestamp into wall-clock ms and computes true photon e2e.
    func recordPresented(presentedTime: CFTimeInterval, captureMs: Double?) {
        guard let captureMs, presentedTime > 0 else { return }
        let presentedWallMs = nowMs - (CACurrentMediaTime() - presentedTime) * 1000
        queue.async {
            guard let offset = self.clockOffsetMs else { return }
            let photon = (presentedWallMs + offset) - captureMs
            if photon > -50, photon < 5000 {
                self.photonWindow.append(max(photon, 0))
            }
        }
    }

    let displayLayer: AVSampleBufferDisplayLayer
    let accessGate: RemoteAccessGate

    /// Native panel size in pixels + scale, announced to the Mac in a "hello"
    /// message so it can size the virtual display. Orientation-dependent:
    /// rotating the phone re-announces with swapped dimensions and the Mac
    /// rebuilds the virtual display as a portrait/landscape monitor.
    private var nativeLong = 0
    private var nativeShort = 0
    private(set) var devicePixelsWide = 0
    private(set) var devicePixelsHigh = 0
    var deviceScale: Double = 2
    // Name advertised over Bonjour for the Mac's WiFi picker. iOS 16+ returns
    // a generic "iPhone" from UIDevice.current.name (the user-assigned name
    // needs an entitlement Apple gates behind approval and personal teams
    // can't get), so this is user-editable in Settings. The USB picker gets
    // the real name host-side via lockdownd regardless.
    var serviceName = "Eva Display"

    // Stable per-install identity, advertised in the Bonjour TXT record and
    // sent in every hello. The Mac uses it to recognize "same device, other
    // transport" — the service name can't serve that role since it's
    // user-editable, and iOS offers no public API for the hardware UDID
    // that usbmuxd reports.
    static let installID: String = {
        if let existing = UserDefaults.standard.string(forKey: "installID") {
            return existing
        }
        let fresh = UUID().uuidString
        UserDefaults.standard.set(fresh, forKey: "installID")
        return fresh
    }()

    private var advertisedService: NWListener.Service {
        var txt = NWTXTRecord()
        txt["id"] = Self.installID
        txt["pv"] = String(WireProtocol.version)   // issue #132
        return NWListener.Service(name: serviceName, type: WirelessSecurity.serviceType,
                                  domain: nil, txtRecord: txt)
    }

    /// Update the advertised name and re-publish if already listening.
    func setServiceName(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let resolved = trimmed.isEmpty ? UIDevice.current.name : trimmed
        queue.async {
            guard resolved != self.serviceName else { return }
            self.serviceName = resolved
            if self.listener != nil {
                self.wirelessListener?.service = self.advertisedService
                Log.info("re-advertising as \"\(resolved)\"")
            }
        }
    }

    func setNativePanel(long: Int, short: Int, scale: Double) {
        nativeLong = long
        nativeShort = short
        deviceScale = scale
        if devicePixelsWide == 0 {   // default landscape until the view reports
            devicePixelsWide = long
            devicePixelsHigh = short
        }
    }

    func setOrientation(portrait: Bool) {
        let w = portrait ? nativeShort : nativeLong
        let h = portrait ? nativeLong : nativeShort
        guard w > 0, w != devicePixelsWide else { return }
        devicePixelsWide = w
        devicePixelsHigh = h
        Log.info("orientation changed -> \(portrait ? "portrait" : "landscape") \(w)x\(h)")
        if let connection { sendHello(on: connection) }
    }

    init(displayLayer: AVSampleBufferDisplayLayer, accessGate: RemoteAccessGate = RemoteAccessGate()) {
        self.displayLayer = displayLayer
        self.accessGate = accessGate
        displayLayer.videoGravity = .resizeAspect
        let code = WirelessSecurity.loadCode(for: "receiver") ?? WirelessSecurity.generateCode()
        if WirelessSecurity.saveCode(code, for: "receiver") {
            wirelessCode = code
            pairingCode = WirelessSecurity.formatted(code)
        } else {
            wirelessStatus = "无法保存配对信息，无线连接未开启；USB 仍可用"
        }
    }

    func setWirelessEnabled(_ enabled: Bool) {
        wirelessEnabled = enabled
        UserDefaults.standard.set(enabled, forKey: "wirelessEnabled")
        queue.async {
            self.stopWirelessListener()
            if enabled { self.startWirelessListener() }
            else {
                if self.transport == "WiFi" {
                    self.connection?.cancel()
                    self.connection = nil
                    self.setConnected(false)
                }
                DispatchQueue.main.async { self.wirelessStatus = "无线连接已关闭" }
            }
            if self.transport == "USB", let conn = self.connection { self.sendHello(on: conn) }
        }
    }

    func renewPairingCode() {
        let code = WirelessSecurity.generateCode()
        guard WirelessSecurity.saveCode(code, for: "receiver") else {
            controlError = "无法保存新的配对码，请重试"
            return
        }
        pairingCode = WirelessSecurity.formatted(code)
        queue.async {
            self.wirelessCode = code
            self.stopWirelessListener()
            if self.transport == "WiFi" {
                self.connection?.cancel(); self.connection = nil; self.setConnected(false)
            }
            if self.wirelessEnabled { self.startWirelessListener() }
            if self.transport == "USB", let conn = self.connection { self.sendHello(on: conn) }
        }
    }

    func start(port: UInt16 = 9000) {
        self.port = port
        queue.async { self.startListener() }
        if !monitorsStarted {
            monitorsStarted = true
            schedulePing()
            scheduleWatchdog()
        }
    }

    /// Recreate the listener if it isn't healthy — called when the app
    /// returns to the foreground (iOS may have torn it down while suspended,
    /// or enterSleep deliberately took it down on lock).
    func ensureListening() {
        queue.async {
            guard !self.listenerHealthy else { return }
            Log.info("listener not healthy — restarting")
            self.restartListener()
        }
    }

    /// Recover half-open sessions while preserving pairing and purchase access.
    func refreshConnection() {
        guard !refreshingConnection else { return }
        refreshingConnection = true
        queue.async {
            self.sendControl(["type": "touch", "phase": "cancelled", "x": 0.0, "y": 0.0])
            self.connection?.stateUpdateHandler = nil
            self.connection?.cancel()
            self.connection = nil
            self.resetStreamState()
            self.displayLayer.flushAndRemoveImage()
            self.setConnected(false)
            DispatchQueue.main.async { self.videoSize = .zero; self.connectionTransport = "—" }
            Log.info("manual connection refresh — restarting USB and wireless listeners")
            self.restartListener()
            self.queue.asyncAfter(deadline: .now() + 1) {
                DispatchQueue.main.async { self.refreshingConnection = false }
            }
        }
    }

    // Set while the app lingers in the background with the session alive
    // (brief app switch): decoding is pointless and hardware decode sessions
    // fail off-screen, so frames are dropped before the sample stage.
    private var renderingPaused = false

    func updateAccess(_ allowed: Bool) {
        queue.async {
            if allowed {
                self.displayLayer.flush()
                self.sendControl(["type": "kf"])
            } else {
                self.sendControl(["type": "touch", "phase": "cancelled", "x": 0.0, "y": 0.0])
                self.displayLayer.flushAndRemoveImage()
            }
        }
    }

    /// Pause/resume the video sink around a background linger. Resuming
    /// flushes the layer and asks the Mac for a keyframe so the picture
    /// re-syncs immediately (the Mac replays a static screen as IDR too).
    func setRenderingPaused(_ paused: Bool) {
        queue.async {
            guard paused != self.renderingPaused else { return }
            self.renderingPaused = paused
            Log.info(paused ? "rendering paused (backgrounded)" : "rendering resumed")
            if !paused {
                self.displayLayer.flush()
                if self.connection?.state == .ready {
                    self.sendControl(["type": "kf"])
                }
            }
        }
    }

    /// The device locked — nobody can see the stream, so tell the Mac and go
    /// silent. Sends "sleeping" (the Mac drops its virtual display so the
    /// cursor isn't stranded on an invisible screen and arms a reconnect),
    /// then closes the connection AND the listener: while asleep we must not
    /// accept connections, or the Mac's wake retries would rebuild the
    /// display before anyone can see it. ensureListening() re-arms
    /// everything when the scene becomes active again.
    func enterSleep(completion: (() -> Void)? = nil) {
        closeSession(announcing: WireMessage.sleeping,
                     status: "Asleep — resumes on wake", completion: completion)
    }

    /// The app is being terminated (user swiped it away). Same close, but
    /// announced as "closing": quitting the app is deliberate, so the Mac
    /// ends the session without waiting around for a wake.
    func shutDown(completion: (() -> Void)? = nil) {
        closeSession(announcing: WireMessage.closing,
                     status: "Closed", completion: completion)
    }

    private func closeSession(announcing type: String, status: String,
                              completion: (() -> Void)?) {
        queue.async {
            self.listenerRestartGeneration += 1
            let generation = self.listenerRestartGeneration
            var finished = false
            let finish = { [weak self] in
                guard let self, !finished else { return }
                finished = true
                guard self.listenerRestartGeneration == generation else { completion?(); return }
                self.connection?.cancel()
                self.connection = nil
                self.stopWirelessListener()
                self.listener?.cancel()
                self.listener = nil
                self.listenerHealthy = false
                self.setConnected(false)
                self.setStatus(status)
                completion?()
            }
            guard let conn = self.connection, conn.state == .ready else {
                Log.info("closing session (\(type)) — no live connection")
                finish()
                return
            }
            Log.info("closing session — announcing \(type) to the Mac")
            self.sendControl(["type": type], on: conn) {
                self.queue.async { finish() }
            }
            // The send completion may never fire on a dying link — don't
            // let that keep us accepting connections after going dark.
            self.queue.asyncAfter(deadline: .now() + 1) { finish() }
        }
    }

    private func restartListener() {
        listenerRestartGeneration += 1
        let generation = listenerRestartGeneration
        stopWirelessListener()
        let previous = listener
        listener = nil
        listenerHealthy = false
        guard let previous else { startListener(); return }
        previous.newConnectionHandler = nil
        if case .cancelled = previous.state { startListener(); return }
        previous.stateUpdateHandler = { [weak self] state in
            guard case .cancelled = state, let self,
                  self.listenerRestartGeneration == generation, self.listener == nil else { return }
            self.startListener()
        }
        previous.cancel()
        queue.asyncAfter(deadline: .now() + 1) { [weak self] in
            guard let self, self.listenerRestartGeneration == generation, self.listener == nil else { return }
            self.startListener()
        }
    }

    private func startListener() {
        do {
            // noDelay matters most in THIS direction: touch events are tiny
            // packets, and Nagle would hold each one until the previous is
            // ACKed — batched, late drags read as input lag.
            let tcp = NWProtocolTCP.Options()
            tcp.noDelay = true
            let params = NWParameters(tls: nil, tcp: tcp)
            params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: port)!)
            params.allowLocalEndpointReuse = true
            params.serviceClass = .interactiveVideo
            listener = try NWListener(using: params)
        } catch {
            setStatus("Listener failed: \(error.localizedDescription)")
            return
        }
        listener?.newConnectionHandler = { [weak self] conn in
            guard let self else { conn.cancel(); return }
            conn.stateUpdateHandler = { [weak self] state in
                guard let self else { return }
                if case .ready = state { self.adopt(conn, transport: "USB") }
            }
            conn.start(queue: self.queue)
        }
        let currentListener = listener
        listener?.stateUpdateHandler = { [weak self, weak currentListener] state in
            guard let self, let currentListener, self.listener === currentListener else { return }
            switch state {
            case .ready:
                self.listenerHealthy = true
                self.setStatus("等待 Mac 通过 USB 或同一 Wi-Fi 连接")
            case .failed(let error):
                Log.info("listener failed: \(error) — restarting in 1s")
                self.listenerHealthy = false
                self.setStatus("Listener failed — restarting…")
                self.queue.asyncAfter(deadline: .now() + 1) {
                    guard self.listener === currentListener else { return }
                    self.restartListener()
                }
            case .cancelled:
                self.listenerHealthy = false
            default: break
            }
        }
        listener?.start(queue: queue)
        if wirelessEnabled { startWirelessListener() }
    }

    private func adopt(_ conn: NWConnection, transport: String) {
        // TLS must complete before the new peer can replace a live session.
        connection?.cancel()
        connection = conn
        self.transport = transport
        resetStreamState()
        lastDataReceived = Date()
        DispatchQueue.main.async { self.connectionTransport = transport }
        setConnected(true)
        conn.stateUpdateHandler = { [weak self, weak conn] state in
            guard let self, let conn, self.connection === conn else { return }
            switch state {
            case .failed, .cancelled: self.setConnected(false)
            default: break
            }
        }
        Log.info("authenticated connection adopted via \(transport)")
        sendHello(on: conn)
        receive(on: conn)
    }

    private func stopWirelessListener() {
        wirelessListener?.stateUpdateHandler = nil
        wirelessListener?.cancel()
        wirelessListener = nil
        for conn in pendingWireless.values { conn.cancel() }
        pendingWireless.removeAll()
    }

    private func startWirelessListener() {
        guard wirelessListener == nil, let code = wirelessCode else { return }
        do {
            let params = WirelessSecurity.parameters(code: code, identity: Self.installID)
            let server = try NWListener(using: params, on: NWEndpoint.Port(rawValue: WirelessSecurity.port)!)
            wirelessListener = server
            server.service = advertisedService
            server.newConnectionHandler = { [weak self] conn in
                guard let self, self.pendingWireless.count < 4 else { conn.cancel(); return }
                let id = ObjectIdentifier(conn)
                self.pendingWireless[id] = conn
                conn.stateUpdateHandler = { [weak self, weak conn] state in
                    guard let self, let conn, self.pendingWireless[id] != nil else { return }
                    switch state {
                    case .ready:
                        self.pendingWireless.removeValue(forKey: id)
                        self.adopt(conn, transport: "WiFi")
                    case .failed, .cancelled:
                        self.pendingWireless.removeValue(forKey: id)
                        conn.cancel()
                    default: break
                    }
                }
                conn.start(queue: self.queue)
                self.queue.asyncAfter(deadline: .now() + 8) { [weak self] in
                    if let stale = self?.pendingWireless.removeValue(forKey: id) { stale.cancel() }
                }
            }
            server.stateUpdateHandler = { [weak self, weak server] state in
                guard let self, let server, self.wirelessListener === server else { return }
                switch state {
                case .ready:
                    DispatchQueue.main.async { self.wirelessStatus = "无线已开启，同一 Wi-Fi 的 Mac 可发现此设备" }
                case .waiting:
                    DispatchQueue.main.async { self.wirelessStatus = "等待本地网络授权或 Wi-Fi，请在系统设置中允许 Eva Display 访问本地网络" }
                case .failed:
                    self.stopWirelessListener()
                    DispatchQueue.main.async { self.wirelessStatus = "无线连接暂不可用，正在重试；USB 仍可用" }
                    self.queue.asyncAfter(deadline: .now() + 3) {
                        if self.wirelessEnabled, self.listener != nil { self.startWirelessListener() }
                    }
                default: break
                }
            }
            server.start(queue: queue)
        } catch {
            DispatchQueue.main.async { self.wirelessStatus = "无法开启无线连接；USB 仍可用" }
        }
    }

    // MARK: - Liveness (ping + watchdog)

    private func schedulePing() {
        queue.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self else { return }
            if self.connection?.state == .ready {
                self.sendControl(["type": "ping", "t": self.nowMs])
            }
            self.schedulePing()
        }
    }

    /// JSON on the video channel (pong, ping liveness) — payloads starting '{'.
    private func handleVideoChannelJSON(_ data: Data) {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let type = obj["type"] as? String else { return }
        switch type {
        case "pong":
            guard let t1 = obj["t"] as? Double, let mt = obj["mt"] as? Double else { return }
            let t2 = nowMs
            let rtt = t2 - t1
            guard rtt >= 0, rtt < 2000 else { return }
            let offset = mt - (t1 + t2) / 2
            offsetSamples.append((rtt, offset))
            if offsetSamples.count > 15 { offsetSamples.removeFirst() }
            if let best = offsetSamples.min(by: { $0.rtt < $1.rtt }) {
                clockOffsetMs = best.offset
            }
            lastRttMs = rtt
        case "ping":
            // The Mac piggybacks its send-side health on liveness pings.
            if let enc = obj["encDrops"] as? Int {
                macEncDrops = enc
            } else if let drops = obj["drops"] as? Int {
                macEncDrops = drops
            }
            if let net = obj["netDrops"] as? Int {
                macNetDrops = net
            }
            macDrops = macEncDrops + macNetDrops
            macPending = obj["pending"] as? Int ?? macPending
            macInputP50 = obj["inp50"] as? Double ?? macInputP50
            macInputP95 = obj["inp95"] as? Double ?? macInputP95
            macCapFps = obj["capFps"] as? Int ?? macCapFps
        case "cursor":
            let visible = (obj["v"] as? Int ?? 0) == 1
            let x = obj["x"] as? Double ?? 0
            let y = obj["y"] as? Double ?? 0
            DispatchQueue.main.async { self.onCursor?(x, y, visible) }
        case "cursorImg":
            guard let b64 = obj["png"] as? String,
                  let png = Data(base64Encoded: b64),
                  let image = UIImage(data: png),
                  let nw = obj["nw"] as? Double, let nh = obj["nh"] as? Double else { return }
            let anchor = CGPoint(x: obj["ax"] as? Double ?? 0, y: obj["ay"] as? Double ?? 0)
            let normSize = CGSize(width: nw, height: nh)
            DispatchQueue.main.async { self.onCursorImage?(image, anchor, normSize) }
        case WireMessage.welcome:
            let features = obj["features"] as? [String] ?? []
            DispatchQueue.main.async {
                self.supportsRemoteInput = features.contains("text-input")
                self.supportsModeSwitch = features.contains("display-mode")
                self.supportsAutomaticKeyboard = features.contains("input-focus")
                if let raw = obj["mode"] as? String { self.activeDisplayMode = RemoteDisplayMode(rawValue: raw) }
            }
            // The Mac identified itself (issue #132). If it speaks a protocol
            // older than we support, it's the Mac that needs updating — and an
            // old Mac can't diagnose that itself, so we surface it here.
            let macPV = obj["pv"] as? Int ?? WireProtocol.assumedWhenAbsent
            if macPV < WireProtocol.minSupportedPeer {
                let msg = "The OpenDisplay app on your Mac is too old for this \(deviceKind) app. Update OpenDisplay on your Mac to reconnect."
                DispatchQueue.main.async { self.peerSignal = .updateMac(message: msg) }
            }
        case WireMessage.inputFocus:
            guard obj["editable"] as? Bool == true else { return }
            DispatchQueue.main.async {
                guard self.connected, self.supportsAutomaticKeyboard, self.supportsRemoteInput else { return }
                self.keyboardRequest &+= 1
            }
        case WireMessage.displayState:
            guard let raw = obj["mode"] as? String, let mode = RemoteDisplayMode(rawValue: raw) else { return }
            let ready = obj["ready"] as? Bool ?? false
            Log.info("display mode state: \(mode.rawValue), ready=\(ready)")
            DispatchQueue.main.async {
                self.activeDisplayMode = mode
                if ready && (self.requestedMode == nil || self.requestedMode == mode) {
                    self.modeSwitchPending = false
                    self.requestedMode = nil
                }
            }
        case WireMessage.updateRequired:
            // The Mac refuses this pairing until we update from the App Store.
            let message = obj["message"] as? String
                ?? "Update OpenDisplay from the App Store to keep using your second display."
            let store = (obj["store"] as? String).flatMap { URL(string: $0) } ?? AppStore.updateURL
            DispatchQueue.main.async { self.peerSignal = .updateIPhone(message: message, storeURL: store) }
        default:
            break
        }
    }

    private func scheduleWatchdog() {
        queue.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self else { return }
            if let conn = self.connection, conn.state == .ready,
               Date().timeIntervalSince(self.lastDataReceived) > 5 {
                Log.info("watchdog: nothing from the Mac for >5s — dropping connection")
                conn.cancel()
                self.connection = nil
                self.setConnected(false)
            }
            self.scheduleWatchdog()
        }
    }

    private func resetStreamState() {
        buffer.removeAll(keepingCapacity: true)
        formatDesc = nil
        sps = nil
        pps = nil
        lastFrameAt = nil
        frameIntervals.removeAll()
        decodeFlushes = 0
        displayLayer.flush()
        if let session = decompressionSession {
            VTDecompressionSessionInvalidate(session)
            decompressionSession = nil
        }
        decodeWindow.removeAll(keepingCapacity: true)
        photonWindow.removeAll(keepingCapacity: true)
    }

    // MARK: - Control messages (phone -> Mac)

    private func sendHello(on conn: NWConnection) {
        var hello: [String: Any] = [
            "type": "hello",
            "pixelsWide": devicePixelsWide,
            "pixelsHigh": devicePixelsHigh,
            "scale": deviceScale,
            "device": UIDevice.current.userInterfaceIdiom == .pad ? "iPad" : "iPhone",
            "id": Self.installID,
            "pv": WireProtocol.version,   // issue #132 — absent on old receivers
        ]
        if transport == "USB", wirelessEnabled, let code = wirelessCode { hello["wifiCode"] = code }
        sendControl(hello, on: conn)
        Log.info("hello sent")
    }

    /// Touch events: x/y normalized [0,1] in video space, origin top-left.
    /// Stamped in *Mac* clock time (our clock + sync offset) so the Mac can
    /// measure touch→injection latency without doing its own clock sync.
    func sendTouch(phase: String, x: Double, y: Double) {
        var msg: [String: Any] = ["type": "touch", "phase": phase, "x": x, "y": y]
        if let offset = clockOffsetMs { msg["t"] = nowMs + offset }
        sendControl(msg)
    }

    /// Two-finger scroll: dx/dy in video pixels (natural-scrolling sign).
    func sendScroll(dx: Double, dy: Double) {
        sendControl(["type": "scroll", "dx": dx, "dy": dy])
    }

    @discardableResult
    func sendText(_ text: String) -> Bool {
        guard accessGate.isAllowed, connected, supportsRemoteInput, RemoteText.isValid(text) else { return false }
        sendControl(["type": WireMessage.text, "text": text])
        return true
    }

    func sendKey(_ key: RemoteKey) {
        guard accessGate.isAllowed, connected, supportsRemoteInput else { return }
        sendControl(["type": WireMessage.key, "key": key.rawValue])
    }

    func requestDisplayMode(_ mode: RemoteDisplayMode) {
        guard accessGate.isAllowed, connected, supportsModeSwitch, !modeSwitchPending, activeDisplayMode != mode else { return }
        controlError = nil
        requestedMode = mode
        modeSwitchPending = true
        modeRequestGeneration += 1
        let generation = modeRequestGeneration
        sendControl(["type": WireMessage.displayMode, "mode": mode.rawValue])
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
            guard let self, self.modeSwitchPending, self.modeRequestGeneration == generation else { return }
            self.modeSwitchPending = false
            self.requestedMode = nil
            self.controlError = "切换尚未完成，请保持连接和接收端前台，再重试。"
        }
    }

    private func sendControl(_ message: [String: Any], on conn: NWConnection? = nil,
                             completion: (() -> Void)? = nil) {
        guard accessGate.allowsControl(type: message["type"] as? String ?? "", phase: message["phase"] as? String) else {
            completion?()
            return
        }
        guard let conn = conn ?? connection,
              let payload = try? JSONSerialization.data(withJSONObject: message) else {
            completion?()
            return
        }
        var header = UInt32(payload.count).bigEndian
        var frame = Data(bytes: &header, count: 4)
        frame.append(payload)
        conn.send(content: frame, completion: .contentProcessed { error in
            if let error { Log.info("control send error: \(error)") }
            completion?()
        })
    }

    // MARK: - Socket read + length-prefixed deframing

    private func receive(on conn: NWConnection) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 1 << 18) {
            [weak self] data, _, isComplete, error in
            guard let self, self.connection === conn else { return }
            if let data, !data.isEmpty {
                self.lastDataReceived = Date()
                self.bytesThisWindow += data.count
                self.buffer.append(data)
                self.drainFrames()
            }
            if let error {
                Log.info("receive error: \(error)")
                return
            }
            if isComplete {
                Log.info("peer closed connection")
                self.setConnected(false)
                return
            }
            self.receive(on: conn)
        }
    }

    private func drainFrames() {
        // Cursor-based drain so we only compact the buffer once per batch.
        var cursor = buffer.startIndex
        while buffer.distance(from: cursor, to: buffer.endIndex) >= 4 {
            let len = buffer[cursor..<buffer.index(cursor, offsetBy: 4)]
                .withUnsafeBytes { Int(UInt32(bigEndian: $0.loadUnaligned(as: UInt32.self))) }
            guard len > 0, len <= 16 * 1024 * 1024 else {
                connection?.cancel()
                buffer.removeAll(keepingCapacity: false)
                setStatus("接收到无效画面，请重新连接")
                return
            }
            guard buffer.distance(from: cursor, to: buffer.endIndex) >= 4 + len else { break }
            let start = buffer.index(cursor, offsetBy: 4)
            let end = buffer.index(start, offsetBy: len)
            handleAnnexB(Data(buffer[start..<end]))
            cursor = end
        }
        buffer.removeSubrange(buffer.startIndex..<cursor)
    }

    // MARK: - Annex B -> CMSampleBuffer

    private func handleAnnexB(_ data: Data) {
        // Pure JSON payload = control message (pong, cursor sprite etc.).
        // Video frames also begin with '{' (telemetry prefix) but always
        // contain start codes — the null bytes make them unambiguous even
        // against multi-KB JSON (cursor sprites are base64, NUL-free).
        if data.count < 32_768, data.first == UInt8(ascii: "{"), !data.contains(0x00) {
            handleVideoChannelJSON(data)
            return
        }

        // Split on 4-byte start codes (our sender only emits 00 00 00 01).
        // Bytes before the FIRST start code are the telemetry prefix
        // ({"cap":…,"snd":…} stamped by the Mac).
        var nalus: [Data] = []
        var metaPrefix: Data?
        data.withUnsafeBytes { (raw: UnsafeRawBufferPointer) in
            let bytes = raw.bindMemory(to: UInt8.self)
            var naluStart: Int? = nil
            var firstSC: Int? = nil
            var i = 0
            while i + 4 <= bytes.count {
                if bytes[i] == 0, bytes[i+1] == 0, bytes[i+2] == 0, bytes[i+3] == 1 {
                    if firstSC == nil { firstSC = i }
                    if let s = naluStart, s < i { nalus.append(Data(bytes[s..<i])) }
                    naluStart = i + 4
                    i += 4
                } else {
                    i += 1
                }
            }
            if let s = naluStart, s < bytes.count { nalus.append(Data(bytes[s...])) }
            if let f = firstSC, f > 0 { metaPrefix = Data(bytes[0..<f]) }
        }

        var captureMs: Double?
        var sendMs: Double?
        if let metaPrefix,
           let meta = try? JSONSerialization.jsonObject(with: metaPrefix) as? [String: Any] {
            captureMs = meta["cap"] as? Double
            sendMs = meta["snd"] as? Double
        }

        var vclNALUs: [Data] = []
        for nalu in nalus {
            guard let first = nalu.first else { continue }
            switch first & 0x1F {
            case 7:                                  // SPS (stream may change
                if sps != nalu {                     //  size on rotation)
                    sps = nalu
                    formatDesc = nil
                }
            case 8:                                  // PPS
                if pps != nalu {
                    pps = nalu
                    formatDesc = nil
                }
            case 6: break                            // SEI — skip
            default: vclNALUs.append(nalu)           // slice data
            }
        }
        if formatDesc == nil, let sps, let pps {
            displayLayer.flush()   // drop any frames from the previous format
            buildFormatDescription(sps: sps, pps: pps)
        }
        guard !vclNALUs.isEmpty else { return }
        // All slices of one wire frame go into ONE sample buffer.
        enqueueFrame(vclNALUs, captureMs: captureMs, sendMs: sendMs)
    }

    private func buildFormatDescription(sps: Data, pps: Data) {
        sps.withUnsafeBytes { spsBuf in
            pps.withUnsafeBytes { ppsBuf in
                let ptrs: [UnsafePointer<UInt8>] = [
                    spsBuf.bindMemory(to: UInt8.self).baseAddress!,
                    ppsBuf.bindMemory(to: UInt8.self).baseAddress!
                ]
                let sizes = [sps.count, pps.count]
                let status = CMVideoFormatDescriptionCreateFromH264ParameterSets(
                    allocator: kCFAllocatorDefault,
                    parameterSetCount: 2,
                    parameterSetPointers: ptrs,
                    parameterSetSizes: sizes,
                    nalUnitHeaderLength: 4,
                    formatDescriptionOut: &formatDesc
                )
                if status == noErr, let formatDesc {
                    let dims = CMVideoFormatDescriptionGetDimensions(formatDesc)
                    Log.info("format description built: \(dims.width)x\(dims.height)")
                    DispatchQueue.main.async {
                        self.videoSize = CGSize(width: Int(dims.width), height: Int(dims.height))
                    }
                    setStatus("Receiving \(dims.width)×\(dims.height)")
                } else {
                    Log.info("format description FAILED: \(status)")
                }
            }
        }
    }

    private func enqueueFrame(_ nalus: [Data], captureMs: Double? = nil, sendMs: Double? = nil) {
        guard let formatDesc else { return }
        // Backgrounded linger: hardware decode is off-limits there, so drop
        // frames at the door instead of feeding a failing display layer at
        // frame rate. setRenderingPaused(false) re-syncs with a keyframe.
        if renderingPaused || !accessGate.isAllowed { return }

        // Build one AVCC buffer: each NALU prefixed with 4-byte big-endian length.
        var avcc = Data(capacity: nalus.reduce(0) { $0 + $1.count + 4 })
        for nalu in nalus {
            var len = UInt32(nalu.count).bigEndian
            avcc.append(Data(bytes: &len, count: 4))
            avcc.append(nalu)
        }

        // Allocate a block buffer that OWNS its memory and copy the bytes in —
        // referencing a transient Swift buffer here is a use-after-free.
        var blockBuffer: CMBlockBuffer?
        guard CMBlockBufferCreateWithMemoryBlock(
                allocator: kCFAllocatorDefault,
                memoryBlock: nil,                   // let CoreMedia allocate
                blockLength: avcc.count,
                blockAllocator: kCFAllocatorDefault,
                customBlockSource: nil, offsetToData: 0,
                dataLength: avcc.count, flags: 0,
                blockBufferOut: &blockBuffer) == noErr,
              let blockBuffer else { return }
        let copyStatus = avcc.withUnsafeBytes { raw in
            CMBlockBufferReplaceDataBytes(
                with: raw.baseAddress!, blockBuffer: blockBuffer,
                offsetIntoDestination: 0, dataLength: avcc.count)
        }
        guard copyStatus == noErr else { return }

        var sample: CMSampleBuffer?
        var sizeArr = [avcc.count]
        CMSampleBufferCreateReady(
            allocator: kCFAllocatorDefault,
            dataBuffer: blockBuffer,
            formatDescription: formatDesc,
            sampleCount: 1,
            sampleTimingEntryCount: 0, sampleTimingArray: nil,
            sampleSizeEntryCount: 1, sampleSizeArray: &sizeArr,
            sampleBufferOut: &sample)

        guard let sample else { return }

        if loggedDisplayPath != (useMetalPath && onDecodedFrame != nil) {
            loggedDisplayPath = useMetalPath && onDecodedFrame != nil
            Log.info("display path: metal=\(useMetalPath) sink=\(onDecodedFrame != nil)")
        }
        if useMetalPath, onDecodedFrame != nil {
            decodeAndRender(sample, captureMs: captureMs)
        } else {
            // Display immediately: low latency, no PTS scheduling.
            if let attachments = CMSampleBufferGetSampleAttachmentsArray(sample, createIfNecessary: true),
               CFArrayGetCount(attachments) > 0 {
                let dict = unsafeBitCast(CFArrayGetValueAtIndex(attachments, 0), to: CFMutableDictionary.self)
                CFDictionarySetValue(dict,
                    Unmanaged.passUnretained(kCMSampleAttachmentKey_DisplayImmediately).toOpaque(),
                    Unmanaged.passUnretained(kCFBooleanTrue).toOpaque())
            }

            if displayLayer.status == .failed {
                Log.info("display layer failed (\(String(describing: displayLayer.error))) — flushing")
                decodeFlushes += 1
                displayLayer.flush()
            }
            if accessGate.isAllowed { displayLayer.enqueue(sample) }
        }

        // Per-frame timing for the performance overlay.
        let now = Date()
        if let last = lastFrameAt {
            let ms = now.timeIntervalSince(last) * 1000
            frameIntervals.append(ms)
            if frameIntervals.count > maxSamples { frameIntervals.removeFirst() }
            if ms > 50 { stallsThisWindow += 1 }
        }
        lastFrameAt = now

        // True end-to-end latency: Mac capture timestamp vs our clock mapped
        // onto the Mac's via the ping/pong offset.
        if let captureMs, let sendMs {
            encodeWindow.append(sendMs - captureMs)
            if let offset = clockOffsetMs {
                let e2e = (nowMs + offset) - captureMs
                if e2e > -50, e2e < 5000 {
                    e2eWindow.append(e2e)
                    e2eRing.append(max(e2e, 0))
                    if e2eRing.count > maxSamples { e2eRing.removeFirst() }
                }
            }
        }

        framesThisWindow += 1
        let elapsed = now.timeIntervalSince(fpsWindowStart)
        if elapsed >= 1.0 {
            let fps = Int(Double(framesThisWindow) / elapsed)
            var stats = PerfStats()
            stats.fps = fps
            stats.mbps = Double(bytesThisWindow) * 8 / elapsed / 1_000_000
            stats.samples = frameIntervals
            if !frameIntervals.isEmpty {
                stats.avgFrameMs = frameIntervals.reduce(0, +) / Double(frameIntervals.count)
                stats.maxFrameMs = frameIntervals.max() ?? 0
            }
            stats.stalls = stallsThisWindow
            stats.decodeFlushes = decodeFlushes
            stats.e2eP50 = percentile(e2eWindow, 0.5)
            stats.e2eP95 = percentile(e2eWindow, 0.95)
            stats.encodeP50 = percentile(encodeWindow, 0.5)
            stats.rttMs = lastRttMs
            stats.e2eSamples = e2eRing
            stats.transport = transport
            stats.macDrops = macDrops
            stats.macEncDrops = macEncDrops
            stats.macNetDrops = macNetDrops
            stats.macPending = macPending
            stats.inputP50 = macInputP50
            stats.inputP95 = macInputP95
            stats.capFps = macCapFps
            stats.decodeP50 = percentile(decodeWindow, 0.5)
            stats.photonP50 = percentile(photonWindow, 0.5)
            stats.photonP95 = percentile(photonWindow, 0.95)
            framesThisWindow = 0
            bytesThisWindow = 0
            stallsThisWindow = 0
            fpsWindowStart = now

            // Every 5s, report the aggregate to the Mac so its log holds the
            // full pipeline picture for offline analysis.
            statsReportCounter += 1
            if statsReportCounter >= 5 {
                statsReportCounter = 0
                sendControl([
                    "type": "stats",
                    "transport": transport,
                    "fps": fps,
                    "mbps": (stats.mbps * 10).rounded() / 10,
                    "e2e50": stats.e2eP50.rounded(),
                    "e2e95": stats.e2eP95.rounded(),
                    "enc50": stats.encodeP50.rounded(),
                    "rtt": lastRttMs.rounded(),
                    "stalls": stats.stalls,
                    "inp50": macInputP50.rounded(),
                    "capFps": macCapFps,
                    "dec50": stats.decodeP50.rounded(),
                    "ph50": stats.photonP50.rounded(),
                    "ph95": stats.photonP95.rounded(),
                    "offsetKnown": clockOffsetMs != nil,
                ])
                e2eWindow.removeAll(keepingCapacity: true)
                encodeWindow.removeAll(keepingCapacity: true)
                decodeWindow.removeAll(keepingCapacity: true)
                photonWindow.removeAll(keepingCapacity: true)
            }

            DispatchQueue.main.async {
                self.fps = fps
                self.perf = stats
            }
        }
    }

    // MARK: - Explicit decode (Metal renderer path)

    private func ensureDecompressionSession() {
        guard let formatDesc else { return }
        if let session = decompressionSession {
            if VTDecompressionSessionCanAcceptFormatDescription(session, formatDescription: formatDesc) {
                return
            }
            VTDecompressionSessionInvalidate(session)
            decompressionSession = nil
        }
        // NV12: the decoder's native output — BGRA would add a conversion
        // pass inside VideoToolbox (measured ~7ms); the YUV→RGB happens in
        // the renderer's fragment shader instead (~free).
        let attrs: [CFString: Any] = [
            kCVPixelBufferPixelFormatTypeKey: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange,
            kCVPixelBufferMetalCompatibilityKey: true,
        ]
        var session: VTDecompressionSession?
        let status = VTDecompressionSessionCreate(
            allocator: nil, formatDescription: formatDesc, decoderSpecification: nil,
            imageBufferAttributes: attrs as CFDictionary, outputCallback: nil,
            decompressionSessionOut: &session)
        if status != noErr { Log.info("VTDecompressionSessionCreate failed: \(status)") }
        decompressionSession = session
    }

    /// Synchronous hardware decode — the handler runs before this returns,
    /// so blocking in the renderer (nextDrawable) is our frame pacing.
    private func decodeAndRender(_ sample: CMSampleBuffer, captureMs: Double?) {
        ensureDecompressionSession()
        guard let session = decompressionSession else { return }
        let t0 = nowMs
        let status = VTDecompressionSessionDecodeFrame(
            session, sampleBuffer: sample, flags: [], infoFlagsOut: nil
        ) { [weak self] status, _, imageBuffer, _, _ in
            guard let self else { return }
            if status == noErr, let imageBuffer, self.accessGate.isAllowed {
                self.decodeWindow.append(self.nowMs - t0)
                self.onDecodedFrame?(imageBuffer, captureMs)
            } else {
                if self.decodeErrorCount % 60 == 0 {
                    Log.info("decode output error: \(status) imageBuffer=\(imageBuffer != nil)")
                }
                self.decodeErrorCount += 1
                // Joined mid-GOP (e.g. the renderer attached after the
                // connect-time IDR, and periodic keyframes are off) — ask
                // the Mac for a fresh sync point.
                self.requestKeyframeIfNeeded()
            }
        }
        if status != noErr {
            decodeFlushes += 1
            decodeErrorCount += 1
            if decodeErrorCount % 60 == 1 {
                Log.info("decode call error: \(status) (\(decodeErrorCount) total)")
            }
            requestKeyframeIfNeeded()
        }
    }

    private var lastKeyframeRequest = Date.distantPast
    private func requestKeyframeIfNeeded() {
        guard Date().timeIntervalSince(lastKeyframeRequest) > 1 else { return }
        lastKeyframeRequest = Date()
        Log.info("requesting keyframe (decoder needs sync)")
        sendControl(["type": "kf"])
    }

    private func percentile(_ values: [Double], _ p: Double) -> Double {
        guard !values.isEmpty else { return 0 }
        let sorted = values.sorted()
        let idx = min(sorted.count - 1, Int(Double(sorted.count) * p))
        return sorted[idx]
    }

    // MARK: - Helpers

    private func setStatus(_ text: String) {
        Log.info("status: \(text)")
        DispatchQueue.main.async { self.status = text }
    }

    private func setConnected(_ value: Bool) {
        DispatchQueue.main.async { self.connected = value }
        if !value { setStatus("等待 Mac 通过 USB 或同一 Wi-Fi 连接") }
        else {
            setStatus("已连接，正在接收画面")
            // Remember the first ever successful connection to a Mac so the
            // first-run onboarding hint never reappears (issue #49).
            if !UserDefaults.standard.bool(forKey: "hasConnectedBefore") {
                UserDefaults.standard.set(true, forKey: "hasConnectedBefore")
            }
        }
    }
}
