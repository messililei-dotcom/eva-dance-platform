import Foundation

enum InterfaceLanguage: String, CaseIterable, Identifiable {
    case system, english = "en", simplifiedChinese = "zh-Hans"
    var id: String { rawValue }
    var label: String {
        switch self {
        case .system: return L10n.text("跟随系统")
        case .english: return "English"
        case .simplifiedChinese: return "简体中文"
        }
    }
}

/// Explicit bundle lookup supports an in-app language override without
/// changing AppleLanguages, restarting the app, or touching remote text.
enum L10n {
    static var selection: InterfaceLanguage {
        InterfaceLanguage(rawValue: UserDefaults.standard.string(forKey: "interfaceLanguage") ?? "") ?? .system
    }
    static func resolve(_ selection: InterfaceLanguage, preferred: [String] = Locale.preferredLanguages) -> String {
        switch selection {
        case .english: return "en"
        case .simplifiedChinese: return "zh-Hans"
        case .system:
            for language in preferred {
                if language.lowercased().hasPrefix("zh") { return "zh-Hans" }
                if language.lowercased().hasPrefix("en") { return "en" }
            }
            return "en"
        }
    }
    static var locale: Locale { Locale(identifier: resolve(selection)) }

    static func text(_ key: String, language: String? = nil, bundle: Bundle = .main) -> String {
        let code = language ?? resolve(selection)
        guard let path = bundle.path(forResource: code, ofType: "lproj"), let localized = Bundle(path: path) else {
            return key
        }
        return localized.localizedString(forKey: key, value: key, table: "Localizable")
    }

    static func format(_ key: String, _ arguments: CVarArg...) -> String {
        String(format: text(key), locale: locale, arguments: arguments)
    }
}
