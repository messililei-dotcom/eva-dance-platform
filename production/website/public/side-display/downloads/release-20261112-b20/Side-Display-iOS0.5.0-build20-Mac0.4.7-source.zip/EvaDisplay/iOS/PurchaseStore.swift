import Foundation
import StoreKit
import Combine

@MainActor
final class PurchaseStore: ObservableObject {
    let gate = RemoteAccessGate()
    @Published private(set) var state: CommerceAccessState = .checking
    @Published private(set) var remainingSeconds = 0
    @Published private(set) var products: [String: Product] = [:]
    @Published private(set) var busy = false
    @Published private(set) var loadingProducts = false
    @Published private(set) var messageKey: String?
    private var updateTask: Task<Void, Never>?
    private var startupTask: Task<Void, Never>?
    private var ticker: Task<Void, Never>?
    private var clock: TrialClock?
    private var savedAt: TimeInterval = 0
    private var revision = 0
    private var started = false

    var hasAccess: Bool { state.permitsAccess && gate.isAllowed }
    var fullPrice: String? { products[CommerceProductID.fullUnlock]?.displayPrice }
    var canPurchase: Bool { !busy && products[CommerceProductID.fullUnlock] != nil && state != .unlocked }
    var canStartTrial: Bool {
        !busy && state == .notStarted && fullPrice != nil
            && products[CommerceProductID.oneHourTrial]?.price == 0
    }
    var countdown: String { String(format: "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60) }

    func start() {
        guard !started else { return }
        started = true
        updateTask = Task { [weak self] in
            for await result in StoreKit.Transaction.updates {
                guard !Task.isCancelled else { return }
                guard case .verified(let transaction) = result else {
                    self?.messageKey = "commerce.verificationFailed"
                    continue
                }
                guard CommerceProductID.all.contains(transaction.productID) else { continue }
                await self?.refreshEntitlements()
                await transaction.finish()
            }
        }
        startupTask = Task { [weak self] in
            await self?.refreshEntitlements()
            await self?.loadProducts()
        }
        ticker = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 1_000_000_000) } catch { return }
                self?.tick()
            }
        }
    }

    deinit { updateTask?.cancel(); startupTask?.cancel(); ticker?.cancel() }

    func loadProducts() async {
        guard !loadingProducts else { return }
        loadingProducts = true
        defer { loadingProducts = false }
        do {
            let loaded = try await Product.products(for: CommerceProductID.all)
            products = Dictionary(uniqueKeysWithValues: loaded.filter { $0.type == .nonConsumable }.map { ($0.id, $0) })
            if products.count != CommerceProductID.all.count { messageKey = "commerce.productsUnavailable" }
            else if products[CommerceProductID.oneHourTrial]?.price != 0 { messageKey = "commerce.trialMustBeFree" }
            else if messageKey == "commerce.productsUnavailable" || messageKey == "commerce.trialMustBeFree" { messageKey = nil }
        } catch { messageKey = "commerce.productsUnavailable" }
    }

    func refreshEntitlements() async {
        revision += 1
        let currentRevision = revision
        var full = false
        var activeTrial = false
        var earliestTrial: (id: UInt64, date: Date)?
        for await result in StoreKit.Transaction.currentEntitlements {
            guard case .verified(let tx) = result, tx.productType == .nonConsumable,
                  tx.revocationDate == nil, tx.expirationDate.map({ $0 > Date() }) ?? true else { continue }
            if tx.productID == CommerceProductID.fullUnlock { full = true }
            if tx.productID == CommerceProductID.oneHourTrial { activeTrial = true }
        }
        // Retain the earliest signed trial date even if a trial is revoked.
        // Restoring/rebuying must never restart its one-hour window.
        for await result in StoreKit.Transaction.all {
            guard case .verified(let tx) = result, tx.productID == CommerceProductID.oneHourTrial,
                  tx.productType == .nonConsumable else { continue }
            if earliestTrial == nil || tx.originalPurchaseDate < earliestTrial!.date {
                earliestTrial = (tx.originalID, tx.originalPurchaseDate)
            }
        }
        guard currentRevision == revision else { return }
        if full {
            clock = nil
            setState(.unlocked)
            return
        }
        guard let trial = earliestTrial else { clock = nil; setState(.notStarted); return }
        guard activeTrial else { clock = nil; setState(.expired); return }
        do {
            let saved = try TrialClockStorage.load(trial.id, startedAt: trial.date)
            // A persisted timestamp cannot replace Apple's signed date.
            if let saved, abs(saved.startedAt - trial.date.timeIntervalSince1970) > 1 {
                throw TrialClockStorage.StorageError.corrupted
            }
            clock = saved ?? TrialClock(originalTransactionID: trial.id, startedAt: trial.date,
                                         now: Date(), uptime: ProcessInfo.processInfo.systemUptime)
            tick(forceSave: true)
        } catch { clock = nil; setState(.storageIssue) }
    }

    func purchaseFullUnlock() async { await purchase(CommerceProductID.fullUnlock) }

    func startTrial(connectionReady: Bool) async {
        guard connectionReady else { messageKey = "commerce.connectFirst"; return }
        guard canStartTrial, products[CommerceProductID.oneHourTrial]?.price == 0 else {
            messageKey = "commerce.trialUnavailable"
            return
        }
        do { try TrialClockStorage.verifyWritable() }
        catch { messageKey = "commerce.storageUnavailable"; return }
        await purchase(CommerceProductID.oneHourTrial)
    }

    private func purchase(_ identifier: String) async {
        guard !busy, let product = products[identifier], product.type == .nonConsumable else { return }
        if identifier == CommerceProductID.oneHourTrial && product.price != 0 {
            messageKey = "commerce.trialMustBeFree"
            return
        }
        busy = true
        messageKey = nil
        defer { busy = false }
        do {
            switch try await product.purchase() {
            case .success(let result):
                guard case .verified(let tx) = result, tx.productID == identifier,
                      tx.revocationDate == nil else { messageKey = "commerce.verificationFailed"; return }
                await refreshEntitlements()
                await tx.finish()
            case .pending: messageKey = "commerce.pending"
            case .userCancelled: messageKey = "commerce.cancelled"
            @unknown default: messageKey = "commerce.purchaseFailed"
            }
        } catch StoreKitError.userCancelled { messageKey = "commerce.cancelled" }
        catch { messageKey = "commerce.purchaseFailed" }
    }

    func restore() async {
        guard !busy else { return }
        busy = true
        messageKey = nil
        defer { busy = false }
        do {
            // Authentication is requested only after the user taps Restore.
            try await StoreKit.AppStore.sync()
            await refreshEntitlements()
            if !hasAccess { messageKey = "commerce.nothingToRestore" }
        } catch { messageKey = "commerce.restoreFailed" }
    }

    func becameActive() async { checkpoint(); await refreshEntitlements() }
    func checkpoint() { tick(forceSave: true) }

    private func tick(forceSave: Bool = false) {
        guard var current = clock else { return }
        let result = current.advance(now: Date(), uptime: ProcessInfo.processInfo.systemUptime)
        clock = current
        let shouldSave = forceSave || Date().timeIntervalSince1970 - savedAt >= 15
            || result.remaining == 0 || result.clockIssue
        do {
            if shouldSave { try TrialClockStorage.save(current); savedAt = Date().timeIntervalSince1970 }
            remainingSeconds = Int(ceil(result.remaining))
            setState(result.remaining <= 0 ? .expired : result.clockIssue ? .clockIssue : .trial,
                     validFor: result.remaining)
        } catch { setState(.storageIssue) }
    }

    private func setState(_ value: CommerceAccessState, validFor seconds: TimeInterval? = nil) {
        gate.setAllowed(value.permitsAccess, validFor: value == .trial ? (seconds ?? 0) : nil)
        state = value
        if value != .trial { remainingSeconds = 0 }
    }
}
