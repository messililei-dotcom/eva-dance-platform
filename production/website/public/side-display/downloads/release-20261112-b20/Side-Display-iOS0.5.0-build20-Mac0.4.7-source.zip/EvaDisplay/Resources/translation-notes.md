# Translation notes

English and Simplified Chinese are first-party interface languages. Chinese literal keys preserve legacy interface copy; semantic keys identify formatted messages.

- `app.deviceSubtitle`: one device-kind placeholder, such as iPhone or iPad.
- `connection.connectedTransport`: USB or Wi-Fi.
- `connection.deviceCount`: integer count, worded without English singular/plural ambiguity.
- `app.version`: app version string.
- `viewport.zoomAccessibility`: integer zoom percentage, then localized edge position.
- Status keys ending in `To` contain device kind/name and pixel resolution as one argument; error keys contain a system error message, kept verbatim.
- Interface language never changes the system keyboard, dictates a recognition language, translates typed text, device names, logs or wire messages. Dictation is provided by the system keyboard and its enabled languages.
