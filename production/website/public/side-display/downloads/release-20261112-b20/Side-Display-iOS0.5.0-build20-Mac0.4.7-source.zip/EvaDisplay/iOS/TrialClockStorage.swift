import Foundation
import Security

enum TrialClockStorage {
    enum StorageError: Error { case unavailable, corrupted }
    static func verifyWritable() throws {
        var q = query(0, startedAt: 0)
        q[kSecAttrAccount as String] = "availability-check"
        let data = Data([1])
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw StorageError.unavailable }
        q[kSecValueData as String] = data
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        guard SecItemAdd(q as CFDictionary, nil) == errSecSuccess else { throw StorageError.unavailable }
    }
    private static func query(_ transactionID: UInt64, startedAt: TimeInterval) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "cn.eva.display.commerce.trial.v1",
         kSecAttrAccount as String: "\(transactionID).\(Int64((startedAt * 1000).rounded()))",
         kSecAttrSynchronizable as String: false]
    }

    static func load(_ transactionID: UInt64, startedAt: Date) throws -> TrialClock? {
        var q = query(transactionID, startedAt: startedAt.timeIntervalSince1970)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        let status = SecItemCopyMatching(q as CFDictionary, &value)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = value as? Data else { throw StorageError.unavailable }
        guard let clock = try? JSONDecoder().decode(TrialClock.self, from: data),
              clock.isValid, clock.originalTransactionID == transactionID else { throw StorageError.corrupted }
        return clock
    }

    static func save(_ clock: TrialClock) throws {
        guard clock.isValid else { throw StorageError.corrupted }
        let data = try JSONEncoder().encode(clock)
        let q = query(clock.originalTransactionID, startedAt: clock.startedAt)
        let update = [kSecValueData as String: data]
        let status = SecItemUpdate(q as CFDictionary, update as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw StorageError.unavailable }
        var item = q.merging(update) { _, new in new }
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        guard SecItemAdd(item as CFDictionary, nil) == errSecSuccess else { throw StorageError.unavailable }
    }
}
