import SwiftUI

struct FloatingSettingsButton: View {
    @ObservedObject private var language = LanguageSettings.shared
    let open: () -> Void
    let refresh: () -> Void
    let refreshing: Bool
    @AppStorage("settingsDockRight") private var dockRight = true
    @AppStorage("settingsDockY") private var dockY = 0.25
    @GestureState private var translation = CGSize.zero
    @ScaledMetric(relativeTo: .body) private var scaledDiameter = 52.0

    var body: some View {
        GeometryReader { geo in
            let diameter = min(scaledDiameter, 72)
            let height = diameter * 2 + 8
            let anchor = ViewportGeometry.dockPoint(in: geo.size, diameter: diameter, right: dockRight, y: dockY)
            let point = CGPoint(x: min(max(anchor.x + translation.width, diameter / 2 + 8), max(diameter / 2 + 8, geo.size.width - diameter / 2 - 8)),
                                y: min(max(anchor.y + translation.height, height / 2 + 8), max(height / 2 + 8, geo.size.height - height / 2 - 8)))
            VStack(spacing: 8) {
                Button(L10n.text("connection.refresh"), systemImage: "arrow.clockwise", action: refresh)
                    .labelStyle(.iconOnly).font(.title2.bold())
                    .frame(width: diameter, height: diameter)
                    .background(Color.accentColor, in: Circle()).foregroundStyle(.white)
                    .disabled(refreshing)
                    .accessibilityIdentifier("floating-refresh")
                    .accessibilityHint(L10n.text("connection.refreshHelp"))
                Button(L10n.text("设置"), systemImage: "gearshape.fill", action: open)
                    .labelStyle(.iconOnly).font(.title2)
                    .accessibilityIdentifier("floating-settings")
                    .frame(width: diameter, height: diameter)
                    .background(.regularMaterial, in: Circle())
                    .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 3)
                    .contentShape(Circle())
            }
                .frame(width: diameter, height: height)
                .position(point)
                .highPriorityGesture(DragGesture(minimumDistance: 8)
                    .updating($translation) { value, state, _ in state = value.translation }
                    .onEnded { value in
                        dockRight = anchor.x + value.translation.width >= geo.size.width / 2
                        let margin = height / 2 + 8
                        dockY = min(max(Double((anchor.y + value.translation.height - margin) / max(geo.size.height - 2 * margin, 1)), 0), 1)
                    })
                .accessibilityHint(L10n.text("点按打开设置，拖动可移动并吸附到屏幕边缘"))
                .accessibilityAction(named: L10n.text("移到左侧")) { dockRight = false }
                .accessibilityAction(named: L10n.text("移到右侧")) { dockRight = true }
                .accessibilityAction(named: L10n.text("重置位置")) { dockRight = true; dockY = 0.25 }
        }
    }
}
