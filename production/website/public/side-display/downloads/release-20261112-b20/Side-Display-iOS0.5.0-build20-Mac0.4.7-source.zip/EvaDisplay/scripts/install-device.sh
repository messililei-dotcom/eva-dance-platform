#!/bin/sh
set -eu
if [ "$#" -ne 2 ]; then
  echo 'Usage: sh scripts/install-device.sh DEVICE_UDID YOUR_TEAM_ID' >&2
  exit 2
fi
root=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
cache="${EVA_DISPLAY_BUILD_ROOT:-$HOME/Library/Caches/EvaDisplayBuild}"
cd "$root"
python3 scripts/generate-project.py
xcodebuild -project EvaDisplay.xcodeproj -scheme EvaDisplayiOS -configuration Debug \
  -destination "id=$1" -derivedDataPath "$cache/device" \
  "DEVELOPMENT_TEAM=$2" -allowProvisioningUpdates -allowProvisioningDeviceRegistration build
xcrun devicectl device install app --device "$1" "$cache/device/Build/Products/Debug-iphoneos/Side Display Receiver.app"
xcrun devicectl device process launch --device "$1" cn.eva.display.receiver
