import Foundation
import Combine

final class LanguageSettings: ObservableObject {
    static let shared = LanguageSettings()
    @Published var selection: InterfaceLanguage {
        didSet {
            UserDefaults.standard.set(selection.rawValue, forKey: "interfaceLanguage")
            NotificationCenter.default.post(name: Self.didChange, object: nil)
        }
    }
    static let didChange = Notification.Name("EvaDisplayInterfaceLanguageDidChange")
    private init() { selection = L10n.selection }
}
