import SwiftUI

/// A compact native composer above the system keyboard. Text remains local
/// until Send, preserving Chinese composition and system dictation.
struct RemoteKeyboardSheet: View {
    @ObservedObject private var language = LanguageSettings.shared
    @ObservedObject var receiver: PhoneReceiver
    @Environment(\.dismiss) private var dismiss
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @FocusState private var focused: Bool
    private var draft: String { receiver.keyboardDraft }
    @State private var error: String?
    let voiceHint: Bool

    private var canSend: Bool { receiver.connected && receiver.supportsRemoteInput && RemoteText.isValid(draft) }
    private var panelHeight: CGFloat { (dynamicTypeSize.isAccessibilitySize ? 240 : 148) + (error != nil ? 32 : (voiceHint ? 24 : 0)) }

    var body: some View {
        VStack(spacing: 4) {
            HStack(alignment: .bottom, spacing: 4) {
                TextField(L10n.text("输入到 Mac…"), text: $receiver.keyboardDraft, axis: .vertical)
                    .lineLimit(1...2)
                    .focused($focused)
                    .font(.body)
                    .padding(.leading, 16)
                    .padding(.vertical, 12)
                    .accessibilityLabel(L10n.text("发送给 Mac 的文字"))
                    .accessibilityIdentifier("remote-text-input")
                Button(action: send) {
                    Label(L10n.text("发送到 Mac"), systemImage: "arrow.up.circle.fill")
                        .labelStyle(.iconOnly)
                        .font(.title)
                        .frame(minWidth: 48, minHeight: 48)
                        .contentShape(Rectangle())
                }
                .padding(.trailing, 4)
                .disabled(!canSend)
                .accessibilityIdentifier("remote-text-send")
            }
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 24))

            if let error {
                Text(L10n.text(error)).font(.caption).foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .accessibilityAddTraits(.updatesFrequently)
            } else if voiceHint {
                Text(L10n.text("轻点系统键盘的麦克风听写"))
                    .font(.caption).foregroundStyle(.secondary)
            }

            HStack(spacing: 0) {
                key(L10n.text("退格"), symbol: "delete.left", .backspace)
                key(L10n.text("回车"), symbol: "return", .enter)
                key("Tab", symbol: "arrow.right.to.line", .tab)
                Menu {
                    menuKey("Esc", .escape)
                    Section(L10n.text("方向键")) {
                        menuKey(L10n.text("向左"), .left); menuKey(L10n.text("向右"), .right)
                        menuKey(L10n.text("向上"), .up); menuKey(L10n.text("向下"), .down)
                    }
                    Section(L10n.text("编辑 Mac")) {
                        menuKey(L10n.text("全选"), .selectAll); menuKey(L10n.text("复制"), .copy)
                        menuKey(L10n.text("粘贴"), .paste); menuKey(L10n.text("撤销"), .undo)
                    }
                    Section {
                        Text(L10n.text("先在 Mac 画面点选输入位置，再输入或听写后发送。"))
                    }
                } label: {
                    Label(L10n.text("更多按键"), systemImage: "ellipsis")
                        .labelStyle(.iconOnly)
                        .frame(minWidth: 48, minHeight: 48)
                        .contentShape(Rectangle())
                }
                .accessibilityIdentifier("remote-more-keys")
                .disabled(!receiver.connected || !receiver.supportsRemoteInput)
                Spacer(minLength: 0)
                Button { dismiss() } label: {
                    Label(L10n.text("收起键盘"), systemImage: "keyboard.chevron.compact.down")
                        .labelStyle(.iconOnly)
                        .frame(minWidth: 48, minHeight: 48)
                        .contentShape(Rectangle())
                }
                .accessibilityIdentifier("remote-text-dismiss")
            }
            .buttonStyle(.plain)
            .font(.body)
            .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 16)
        .padding(.top, 20)
        .padding(.bottom, 8)
        .frame(maxWidth: .infinity, alignment: .top)
        .background(Color(uiColor: .systemBackground))
        .presentationDetents([.height(panelHeight)])
        .modifier(CompactKeyboardPresentation())
        .presentationDragIndicator(.visible)
        .task { focused = true }
        .onChange(of: draft) { _ in
            error = draft.utf16.count > RemoteText.maximumUTF16 ? "文字过长，请分段发送（最多 4096 字符单位）" : nil
        }
    }

    private func send() {
        if receiver.sendText(draft) {
            receiver.keyboardDraft = ""
            error = nil
            focused = true
        } else {
            error = "未能发送，请检查 Mac 连接"
        }
    }

    private func key(_ title: String, symbol: String, _ value: RemoteKey) -> some View {
        Button { receiver.sendKey(value) } label: {
            Label(L10n.text(title), systemImage: symbol)
                .labelStyle(.iconOnly)
                .frame(minWidth: 48, minHeight: 48)
                .contentShape(Rectangle())
        }
        .accessibilityIdentifier("remote-key-\(value.rawValue)")
        .disabled(!receiver.connected || !receiver.supportsRemoteInput)
    }

    private func menuKey(_ title: String, _ value: RemoteKey) -> some View {
        Button(L10n.text(title)) { receiver.sendKey(value) }
            .accessibilityIdentifier("remote-key-\(value.rawValue)")
    }
}
