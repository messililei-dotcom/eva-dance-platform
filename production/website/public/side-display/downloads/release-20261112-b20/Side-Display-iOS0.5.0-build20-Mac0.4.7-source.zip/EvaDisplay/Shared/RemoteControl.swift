import Foundation

enum RemoteDisplayMode: String, CaseIterable {
    case extend, mirror
    var label: String { self == .extend ? L10n.text("扩展屏幕") : L10n.text("实时屏幕") }
}

enum RemoteKey: String, CaseIterable {
    case backspace, enter, tab, escape, left, right, up, down, selectAll, copy, paste, undo
}

enum RemoteText {
    static let maximumUTF16 = 4096
    static func isValid(_ text: String) -> Bool {
        !text.isEmpty && text.utf16.count <= maximumUTF16 && !text.contains("\0")
    }
    /// Keep composed characters and surrogate pairs intact across CGEvents.
    static func chunks(_ text: String, limit: Int = 20) -> [String] {
        var result: [String] = [], current = ""
        for character in text {
            let value = String(character)
            if !current.isEmpty && current.utf16.count + value.utf16.count > limit {
                result.append(current); current = ""
            }
            current += value
        }
        if !current.isEmpty { result.append(current) }
        return result
    }
}
