import SwiftUI
import AVFoundation

@MainActor
final class ViewportState: ObservableObject {
    @Published var zoom = 1.0
    @Published var edgeState = "自由位置"
    @Published var moveViewport = false
    @Published var fillViewport = (UserDefaults.standard.object(forKey: "fillViewport") as? Bool) ?? true {
        didSet { UserDefaults.standard.set(fillViewport, forKey: "fillViewport") }
    }
    @Published private(set) var command = 0
    private(set) var targetZoom = 1.0
    func changeZoom(to value: Double) {
        targetZoom = min(max(value.isFinite ? value : 1, 1), 12)
        command += 1
    }
    func fit() { moveViewport = false; changeZoom(to: 1) }
}

struct ZoomableVideoView: UIViewRepresentable {
    let displayLayer: AVSampleBufferDisplayLayer
    let receiver: PhoneReceiver
    let useMetal: Bool
    @ObservedObject var viewport: ViewportState

    func makeUIView(context: Context) -> ZoomVideoContainer {
        ZoomVideoContainer(video: VideoLayerView.makeVideoView(displayLayer: displayLayer,
                                                              receiver: receiver, useMetal: useMetal),
                           viewport: viewport)
    }
    func updateUIView(_ container: ZoomVideoContainer, context: Context) {
        container.apply(viewport, videoSize: receiver.videoSize)
    }
}

final class ZoomVideoContainer: UIView, UIScrollViewDelegate {
    private let scroll = UIScrollView()
    let video: VideoLayerView.VideoView
    private weak var viewport: ViewportState?
    private var previousSize = CGSize.zero
    private var previousVideoSize = CGSize.zero
    private var fillViewport = true
    private var needsRefit = true
    private var clamping = false
    private var pendingZoomSnap = false
    private var appliedCommand = 0

    init(video: VideoLayerView.VideoView, viewport: ViewportState) {
        self.video = video; self.viewport = viewport
        super.init(frame: .zero)
        backgroundColor = .black
        scroll.delegate = self
        scroll.minimumZoomScale = 1
        scroll.maximumZoomScale = 12
        scroll.bouncesZoom = false
        scroll.bounces = false
        scroll.alwaysBounceHorizontal = false
        scroll.alwaysBounceVertical = false
        scroll.contentInsetAdjustmentBehavior = .never
        scroll.delaysContentTouches = false
        scroll.showsVerticalScrollIndicator = false
        scroll.showsHorizontalScrollIndicator = false
        scroll.panGestureRecognizer.isEnabled = false
        addSubview(scroll); scroll.addSubview(video)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layoutSubviews() {
        super.layoutSubviews()
        scroll.frame = bounds
        guard bounds.size != previousSize || needsRefit, bounds.width > 0, bounds.height > 0 else { return }
        previousSize = bounds.size
        needsRefit = false
        scroll.setZoomScale(1, animated: false)
        let size = ViewportGeometry.videoSize(previousVideoSize, in: bounds.size, fill: fillViewport)
        video.frame = CGRect(origin: .zero, size: size)
        scroll.contentSize = size
        updateInsets()
        centerContent()
        video.setNeedsLayout()
    }

    func apply(_ state: ViewportState, videoSize: CGSize) {
        viewport = state
        if videoSize != previousVideoSize || fillViewport != state.fillViewport {
            previousVideoSize = videoSize
            fillViewport = state.fillViewport
            needsRefit = true
            setNeedsLayout()
        }
        scroll.panGestureRecognizer.isEnabled = state.moveViewport
        video.isUserInteractionEnabled = !state.moveViewport
        video.remoteGesturesSuspended = state.moveViewport || scroll.isZooming
        if state.moveViewport { video.cancelRemoteGesture() }
        if appliedCommand != state.command {
            appliedCommand = state.command
            scroll.setZoomScale(CGFloat(state.targetZoom), animated: false)
            if state.targetZoom == 1 { centerContent() }
            else { snapToNearestEdge() }
        }
        video.setNeedsLayout()
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? { video }
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
        pendingZoomSnap = false
        video.cancelRemoteGesture()
        video.remoteGesturesSuspended = true
    }
    func scrollViewDidZoom(_ scrollView: UIScrollView) {
        updateInsets()
        let zoom = Double(scrollView.zoomScale)
        DispatchQueue.main.async { [weak self] in
            guard let state = self?.viewport, abs(state.zoom - zoom) > 0.005 else { return }
            state.zoom = zoom
        }
    }
    func scrollViewDidEndZooming(_ scrollView: UIScrollView, with view: UIView?, atScale scale: CGFloat) {
        video.remoteGesturesSuspended = viewport?.moveViewport == true
        if scroll.isDragging || scroll.isDecelerating { pendingZoomSnap = true }
        else { snapToNearestEdge() }
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) { clampOffset(); publishEdge() }
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) { clampOffset() }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if pendingZoomSnap { snapToNearestEdge() }
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate && pendingZoomSnap { snapToNearestEdge() }
    }

    private func snapToNearestEdge() {
        pendingZoomSnap = false
        let edge = ViewportGeometry.nearestEdge(offset: scroll.contentOffset, content: scroll.contentSize, viewport: scroll.bounds.size)
        let point = ViewportGeometry.zoomOffset(from: scroll.contentOffset, anchor: .zero,
            oldScale: scroll.zoomScale, newScale: scroll.zoomScale,
            content: scroll.contentSize, viewport: scroll.bounds.size, edge: edge)
        scroll.setContentOffset(point, animated: false)
        clampOffset()
        publishEdge()
    }

    private func publishEdge() {
        let offset = scroll.contentOffset, content = scroll.contentSize, size = scroll.bounds.size
        let names: [(String, CGFloat)] = [("左侧吸附", abs(offset.x)), ("右侧吸附", abs(content.width - size.width - offset.x)),
                                         ("上侧吸附", abs(offset.y)), ("下侧吸附", abs(content.height - size.height - offset.y))]
        let nearest = names.min { $0.1 < $1.1 }!
        let text = nearest.1 <= 0.5 ? nearest.0 : "自由位置"
        DispatchQueue.main.async { [weak self] in
            guard let viewport = self?.viewport, viewport.edgeState != text else { return }
            viewport.edgeState = text
        }
    }

    private func updateInsets() {
        let x = max((scroll.bounds.width - scroll.contentSize.width) / 2, 0)
        let y = max((scroll.bounds.height - scroll.contentSize.height) / 2, 0)
        let inset = UIEdgeInsets(top: y, left: x, bottom: y, right: x)
        if scroll.contentInset != inset { scroll.contentInset = inset }
    }
    private func centerContent() {
        scroll.contentOffset = CGPoint(x: (scroll.contentSize.width - scroll.bounds.width) / 2,
                                       y: (scroll.contentSize.height - scroll.bounds.height) / 2)
        clampOffset()
    }
    private func clampOffset() {
        guard !clamping else { return }
        let point = ViewportGeometry.clampedOffset(scroll.contentOffset, content: scroll.contentSize, viewport: scroll.bounds.size)
        guard abs(point.x - scroll.contentOffset.x) > 0.25 || abs(point.y - scroll.contentOffset.y) > 0.25 else { return }
        clamping = true
        scroll.contentOffset = point
        clamping = false
    }
}
