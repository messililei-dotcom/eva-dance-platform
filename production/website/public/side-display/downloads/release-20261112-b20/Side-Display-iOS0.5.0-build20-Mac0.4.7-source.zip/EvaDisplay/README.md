# Side Display · 随身副屏 — iOS 0.5.0 候选版

当前源码候选版：iOS 0.5.0 (20)、Mac 0.4.7 (15)。两端免费，连接后可不限时使用实时屏幕、扩展屏幕和远程控制。图标延续白底设备与蓝色箭头构图，移除 Apple 标志。发行和审核状态以 Apple 后台及[产品网站](https://www.swod.com.cn/side-display/release-0.5.0.html)为准。

包含功能说明、操作步骤和实际软件截图的产品介绍：[简体中文](release/apple-review-20261101/product/PRODUCT.zh-Hans.md) · [English](release/apple-review-20261101/product/PRODUCT.en.md)。

**让 iPhone 和 iPad 成为 Mac 的第二块屏幕。**

支持 USB 和同一 Wi-Fi 无线连接，可选择独立扩展桌面或实时显示主屏，并通过触控、缩放、手机键盘和系统听写操作 Mac。

[English](README.en.md)

0.4.3 两端采用用户确认的 v5 图标：Mac mini 机身加高、苹果标志更明显，已安装到 Mac 和 iPhone，见 [图标更新](ICON-0.4.3.md)。保留 [0.4.2 Dock 圆角与尺寸修复](MAC-ICON-0.4.2.md)。

0.4.4 按用户要求去掉英文名称的 Eva 前缀，改为 Side Display，图标短名 Side；中文仍为随身副屏。名称调整不改变应用身份、配对或设置。Mac 与本次连接的 iPhone 均已安装 0.4.4 / build 12，见 [更名记录](NAME-0.4.4.md)。

## 本次更新

用户已确认新名称与白底 Mac mini→iPhone＋iPad 图标。Mac 程序改为 `~/Applications/Side Display.app`；手机中文名“随身副屏”，英文图标短名“Side”，应用内完整英文名“Side Display”。原应用标识、无线配对、设置和权限身份保持不变。

两端支持“跟随系统 / 简体中文 / English”，在“语言 / Language”中即时切换。系统找不到支持的语言时回退英文。系统授权说明、本地化应用名、连接状态、错误、触控标签与说明均有两种语言。系统键盘使用地球键选择中英文；界面语言不会更改键盘语言，也不翻译输入内容。

详见 [中英文与品牌记录](LOCALIZATION-0.4.1.md)。

## 使用

1. Mac 打开 `Side Display.app`。下载测试包为 `dist/Side-Display-0.4.4-mac.zip`。
2. iPhone/iPad 安装并打开“随身副屏 / EvaSide”。开发安装需自己的 Apple 签名和开发者模式。
3. USB：使用数据线连接、解锁并信任本机。接过 USB 会自动保存无线配对。
4. 无线：两端连接同一 Wi-Fi，允许本地网络访问；Mac 也可通过网线连接同一路由器。没有接过 USB 时，在 Mac 输入设备设置中的配对码。
5. Mac 授权屏幕录制；需要触控和键盘操作时授权辅助功能。接收端保持解锁及前台。
6. “扩展屏幕 / Extended Display”新增独立桌面，可在 Mac 的“排列屏幕”中设置位置。“实时屏幕 / Mirror Screen”显示主屏相同桌面。
7. 单指点击／拖动，双指滚动和捏合缩放；“移动画面”开启时拖动视口，关闭后操作 Mac。默认等比铺满，亦可完整显示。
8. 点中可编辑输入框自动弹出原生紧凑输入条；输入或听写后点向上箭头发送。更多快捷键收在菜单中。关闭再打开输入条可继续草稿，发送成功清空。

无线采用本地 TLS 配对加密，无云账号或中继。配对码不通过 Bonjour 广播；仅存设备钥匙串。USB 监听限回环地址。拔线自动切换可用的 Wi-Fi，重新插线优先 USB。

## 支持与验收边界

- macOS 14+，iOS/iPadOS 16+；Mac 为 Apple Silicon / Intel 通用构建。低版本系统使用原生布局回退，不表示已逐台真机验证。
- 实体 iPhone 14 Pro Max 曾完成 USB/Wi-Fi、主屏镜像、独立扩展、触控、缩放、键盘、系统听写及紧凑输入验收。中英文切换已做 iPhone/iPad 模拟器检查，用户也已确认 0.4.1 的名称、图标、双语切换和连接正常。
- 本机 5120×2880 原生镜像已验证；帧率随内容、编码和网络变化，均衡或流畅档可主动降低分辨率。
- iPad 真机、旧系统真机、多台实体设备并发、无实体显示器冷启动仍待验收。不能用于 FileVault、开机登录或恢复模式。
- 当前是本地开发签名测试版，未作为全球商店版本发布或公证。

历史证据：[无线](WIRELESS.md)、[紧凑输入](KEYBOARD-0.3.1.md)、[缩放](PINCH-VALIDATION.md)、[设备适配](COMPATIBILITY.md)。

## 构建与测试

```sh
python3 scripts/generate-project.py
sh scripts/build.sh mac
sh scripts/install-device.sh DEVICE_UDID APPLE_TEAM_ID
sh scripts/test-localization.sh
sh scripts/test-wireless.sh
```

构建缓存默认在 `~/Library/Caches/EvaDisplayBuild`。Mac 可设置 `EVA_DISPLAY_SIGN_IDENTITY` 使用已有开发签名；iOS 需自己的签名。`scripts/package-source.py` 生成对应源码包，保留许可证、图标母图与生成提示词。技术目录和 Xcode target 仍名为 EvaDisplay，避免破坏现有工程和自动化。

基于 [OpenDisplay](https://github.com/peetzweg/opendisplay) 修改，遵循 GPL-3.0；见 [LICENSE](LICENSE) 与 [来源说明](THIRD_PARTY.md)。它与父目录 Eva Remote 是独立程序。

主动刷新连接 / Manual connection refresh: [实现与验证](REFRESH-CONNECTION.md)。
