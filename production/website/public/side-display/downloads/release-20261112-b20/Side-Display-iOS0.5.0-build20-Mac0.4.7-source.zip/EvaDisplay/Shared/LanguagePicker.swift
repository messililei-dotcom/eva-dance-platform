import SwiftUI

struct LanguagePicker: View {
    @ObservedObject private var language = LanguageSettings.shared
    var body: some View {
        Picker("语言 / Language", selection: $language.selection) {
            ForEach(InterfaceLanguage.allCases) { choice in
                Text(choice.label).tag(choice)
            }
        }
        .pickerStyle(.menu)
        .id(language.selection)
        .accessibilityIdentifier("interface-language")
    }
}
