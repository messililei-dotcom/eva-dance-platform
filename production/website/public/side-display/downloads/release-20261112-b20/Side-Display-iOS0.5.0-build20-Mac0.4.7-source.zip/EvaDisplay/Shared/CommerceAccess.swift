import Foundation

enum CommerceProductID {
    static let fullUnlock = "cn.eva.display.receiver.fullunlock"
    static let oneHourTrial = "cn.eva.display.receiver.trial.1hour"
    static let all = [fullUnlock, oneHourTrial]
}

enum CommerceAccessState: String {
    case checking, notStarted, trial, unlocked, expired, clockIssue, storageIssue
    var permitsAccess: Bool { self == .trial || self == .unlocked }
    var localizationKey: String {
        switch self {
        case .checking: return "commerce.state.checking"
        case .notStarted: return "commerce.state.notStarted"
        case .trial: return "commerce.state.trial"
        case .unlocked: return "commerce.state.unlocked"
        case .expired: return "commerce.state.expired"
        case .clockIssue: return "commerce.state.clockIssue"
        case .storageIssue: return "commerce.state.storageIssue"
        }
    }
}

/// Contains no paid-unlock flag. Paid access always comes from StoreKit.
/// The signed original purchase date anchors the one-hour window. Persisted
/// high-water marks and uptime prevent ordinary clock rollback extending it.
struct TrialClock: Codable, Equatable {
    static let duration: TimeInterval = 3_600
    let originalTransactionID: UInt64
    let startedAt: TimeInterval
    private(set) var consumed: TimeInterval
    private(set) var lastWallTime: TimeInterval
    private(set) var lastUptime: TimeInterval

    init(originalTransactionID: UInt64, startedAt: Date, now: Date, uptime: TimeInterval) {
        self.originalTransactionID = originalTransactionID
        self.startedAt = startedAt.timeIntervalSince1970
        consumed = min(Self.duration, max(0, now.timeIntervalSince(startedAt)))
        lastWallTime = now.timeIntervalSince1970
        lastUptime = uptime
    }

    var isValid: Bool {
        [startedAt, consumed, lastWallTime, lastUptime].allSatisfy(\.isFinite)
            && startedAt > 0 && consumed >= 0 && consumed <= Self.duration && lastUptime >= 0
    }

    mutating func advance(now: Date, uptime: TimeInterval) -> (remaining: TimeInterval, clockIssue: Bool) {
        let wall = now.timeIntervalSince1970
        let rollback = wall < max(startedAt, lastWallTime) - 5
        // After a reboot, uptime usually resets; the wall delta accounts for
        // the gap. On the same boot, monotonic time also covers manual edits.
        let monotonicDelta = max(0, uptime - lastUptime)
        consumed = min(Self.duration, max(consumed + monotonicDelta, wall - startedAt))
        lastWallTime = max(lastWallTime, wall)
        lastUptime = uptime
        return (max(0, Self.duration - consumed), rollback)
    }
}

/// Shared by StoreKit's main-actor state and the receiver's network queue.
/// Default-deny; no preference or launch argument can grant paid access.
final class RemoteAccessGate {
    private let lock = NSLock()
    private var allowed = false
    private var uptimeDeadline: TimeInterval?
    private var wallDeadline: TimeInterval?
    var isAllowed: Bool {
        lock.lock(); defer { lock.unlock() }
        guard allowed else { return false }
        if let uptimeDeadline, ProcessInfo.processInfo.systemUptime >= uptimeDeadline { return false }
        if let wallDeadline, Date().timeIntervalSince1970 >= wallDeadline { return false }
        return true
    }
    func setAllowed(_ value: Bool, validFor seconds: TimeInterval? = nil) {
        lock.lock(); defer { lock.unlock() }
        allowed = value
        uptimeDeadline = seconds.map { ProcessInfo.processInfo.systemUptime + max(0, $0) }
        wallDeadline = seconds.map { Date().timeIntervalSince1970 + max(0, $0) }
    }
    func allowsControl(type: String, phase: String? = nil) -> Bool {
        let inputTypes = ["touch", "scroll", WireMessage.text, WireMessage.key, WireMessage.displayMode]
        guard inputTypes.contains(type) else { return true }
        // Releasing an already held mouse button must remain possible.
        return isAllowed || (type == "touch" && phase == "cancelled")
    }
}
