import CoreGraphics

enum ViewportGeometry {
    enum Edge: CaseIterable { case left, right, top, bottom }

    static func nearestEdge(offset: CGPoint, content: CGSize, viewport: CGSize) -> Edge {
        let point = clampedOffset(offset, content: content, viewport: viewport)
        let distances: [(Edge, CGFloat)] = [(.left, abs(point.x)),
            (.right, abs(content.width - viewport.width - point.x)),
            (.top, abs(point.y)), (.bottom, abs(content.height - viewport.height - point.y))]
        return distances.min { $0.1 < $1.1 }!.0
    }

    /// Keep one selected edge fixed while preserving the pinch point on the other axis.
    static func zoomOffset(from offset: CGPoint, anchor: CGPoint, oldScale: CGFloat, newScale: CGFloat,
                           content: CGSize, viewport: CGSize, edge: Edge) -> CGPoint {
        let ratio = oldScale > 0 ? newScale / oldScale : 1
        var point = CGPoint(x: (offset.x + anchor.x) * ratio - anchor.x,
                            y: (offset.y + anchor.y) * ratio - anchor.y)
        switch edge {
        case .left: point.x = 0
        case .right: point.x = max(content.width - viewport.width, 0)
        case .top: point.y = 0
        case .bottom: point.y = max(content.height - viewport.height, 0)
        }
        return clampedOffset(point, content: content, viewport: viewport)
    }

    static func videoSize(_ video: CGSize, in viewport: CGSize, fill: Bool) -> CGSize {
        guard video.width > 0, video.height > 0, viewport.width > 0, viewport.height > 0,
              video.width.isFinite, video.height.isFinite else { return viewport }
        let x = viewport.width / video.width, y = viewport.height / video.height
        let scale = fill ? max(x, y) : min(x, y)
        return CGSize(width: video.width * scale, height: video.height * scale)
    }

    static func clampedOffset(_ offset: CGPoint, content: CGSize, viewport: CGSize) -> CGPoint {
        func axis(_ value: CGFloat, _ content: CGFloat, _ viewport: CGFloat) -> CGFloat {
            let inset = max((viewport - content) / 2, 0)
            let minimum = -inset, maximum = max(minimum, content - viewport + inset)
            return min(max(value.isFinite ? value : minimum, minimum), maximum)
        }
        return CGPoint(x: axis(offset.x, content.width, viewport.width),
                       y: axis(offset.y, content.height, viewport.height))
    }

    static func dockPoint(in size: CGSize, diameter: CGFloat, right: Bool, y: Double) -> CGPoint {
        let margin = diameter / 2 + 8
        let low = min(margin, size.height / 2), high = max(low, size.height - margin)
        let fraction = CGFloat(min(max(y.isFinite ? y : 0.25, 0), 1))
        return CGPoint(x: right ? max(size.width - margin, size.width / 2) : min(margin, size.width / 2),
                       y: low + (high - low) * fraction)
    }
}
