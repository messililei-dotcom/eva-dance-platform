import SwiftUI

/// Keep the composer fitted on iPad and retain a sheet in compact height.
/// Older systems retain the native detent fallback without raising the target.
struct CompactKeyboardPresentation: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content
                .presentationSizing(.form.fitted(horizontal: false, vertical: true))
                .presentationCompactAdaptation(.sheet)
        } else if #available(iOS 16.4, *) {
            content.presentationCompactAdaptation(.sheet)
        } else {
            content
        }
    }
}
