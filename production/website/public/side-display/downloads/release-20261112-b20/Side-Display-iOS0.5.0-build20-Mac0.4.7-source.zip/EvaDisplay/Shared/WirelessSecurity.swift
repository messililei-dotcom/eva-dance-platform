import Foundation
import Network
import Security
import CryptoKit

/// Bonjour contains only public identity. The secret travels over trusted USB,
/// or is entered from the receiver's settings; never advertised or logged.
enum WirelessSecurity {
    static let serviceType = "_evadisplay._tcp"
    static let port: UInt16 = 9001
    private static let alphabet = Array("23456789ABCDEFGHJKLMNPQRSTUVWXYZ")

    static func normalize(_ text: String) -> String? {
        let code = text.uppercased().filter { !$0.isWhitespace && $0 != "-" }
        guard code.count == 20, code.allSatisfy({ alphabet.contains($0) }) else { return nil }
        return code
    }

    static func generateCode() -> String {
        var random = SystemRandomNumberGenerator()
        return String((0..<20).map { _ in alphabet.randomElement(using: &random)! })
    }

    static func formatted(_ code: String) -> String {
        stride(from: 0, to: code.count, by: 4).map {
            String(code.dropFirst($0).prefix(4))
        }.joined(separator: "-")
    }

    static func parameters(code: String, identity: String) -> NWParameters {
        precondition(normalize(code) != nil)
        let secret = Data(SHA256.hash(data: Data(("EvaDisplay-WiFi-v1:" + normalize(code)!).utf8)))
        let tls = NWProtocolTLS.Options()
        let options = tls.securityProtocolOptions
        sec_protocol_options_set_min_tls_protocol_version(options, .TLSv12)
        sec_protocol_options_set_max_tls_protocol_version(options, .TLSv12)
        sec_protocol_options_append_tls_ciphersuite(options, tls_ciphersuite_t(rawValue: 0x00A8)!) // TLS_PSK_WITH_AES_128_GCM_SHA256
        let key = secret.withUnsafeBytes { DispatchData(bytes: $0) }
        let peer = Data(identity.utf8).withUnsafeBytes { DispatchData(bytes: $0) }
        sec_protocol_options_add_pre_shared_key(options, key as __DispatchData, peer as __DispatchData)
        let tcp = NWProtocolTCP.Options()
        tcp.noDelay = true
        let params = NWParameters(tls: tls, tcp: tcp)
        params.prohibitedInterfaceTypes = [.cellular]
        params.serviceClass = .interactiveVideo
        return params
    }

    static func loadCode(for identity: String) -> String? {
        var query = keychainQuery(identity)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &value) == errSecSuccess,
              let data = value as? Data, let text = String(data: data, encoding: .utf8) else { return nil }
        return normalize(text)
    }

    @discardableResult
    static func saveCode(_ code: String, for identity: String) -> Bool {
        guard let normalized = normalize(code) else { return false }
        let query = keychainQuery(identity)
        let values = [kSecValueData as String: Data(normalized.utf8)]
        let status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
        if status == errSecSuccess { return true }
        guard status == errSecItemNotFound else { return false }
        var item = query.merging(values) { _, new in new }
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    private static func keychainQuery(_ identity: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "cn.eva.display.wireless",
         kSecAttrAccount as String: identity,
         kSecAttrSynchronizable as String: false]
    }
}
