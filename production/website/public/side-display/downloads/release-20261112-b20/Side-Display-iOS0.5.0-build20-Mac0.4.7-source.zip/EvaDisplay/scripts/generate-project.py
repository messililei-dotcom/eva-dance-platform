#!/usr/bin/env python3
"""Generate a dependency-free Xcode project using Apple's plist format."""
from pathlib import Path
import hashlib
import plistlib
import os

ROOT = Path(__file__).resolve().parent.parent
objects = {}
commerce_enabled = os.environ.get('EVA_DISPLAY_COMMERCE') == '1'


def oid(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()


def obj(identity, isa, **fields):
    key = oid(identity)
    objects[key] = dict(isa=isa, **fields)
    return key


def config_list(name, settings):
    configs = [obj(name + conf, 'XCBuildConfiguration', name=conf, buildSettings=settings)
               for conf in ['Debug', 'Release']]
    return obj(name + 'configs', 'XCConfigurationList', buildConfigurations=configs,
               defaultConfigurationIsVisible=0, defaultConfigurationName='Debug')


targets, products, groups = [], [], []
for name, platform, folder, bundle_id, product_name in [
    ('EvaDisplayMac', 'macosx', 'Mac', 'cn.eva.display.mac', 'Side Display'),
    ('EvaDisplayiOS', 'iphoneos', 'iOS', 'cn.eva.display.receiver', 'Side Display Receiver'),
]:
    files, sources, resources = [], [], []
    for file in sorted(list((ROOT / folder).glob('*.swift')) + list((ROOT / 'Shared').glob('*.swift'))):
        if file.name.startswith('.'):
            continue
        rel = str(file.relative_to(ROOT))
        ref = obj(name + rel, 'PBXFileReference', path=rel, sourceTree='SOURCE_ROOT', lastKnownFileType='sourcecode.swift')
        files.append(ref)
        sources.append(obj(name + rel + 'build', 'PBXBuildFile', fileRef=ref))
    asset = obj(name + 'assets', 'PBXFileReference', path=folder + '/Assets.xcassets',
                sourceTree='SOURCE_ROOT', lastKnownFileType='folder.assetcatalog')
    files.append(asset)
    resources.append(obj(name + 'assetsbuild', 'PBXBuildFile', fileRef=asset))
    privacy = ROOT / folder / 'PrivacyInfo.xcprivacy'
    if privacy.exists():
        ref = obj(name + 'privacy', 'PBXFileReference', path=folder + '/PrivacyInfo.xcprivacy',
                  sourceTree='SOURCE_ROOT', lastKnownFileType='text.xml')
        files.append(ref)
        resources.append(obj(name + 'privacybuild', 'PBXBuildFile', fileRef=ref))
    for resource in ['Localizable.strings', 'InfoPlist.strings']:
        localized = [obj(name + lang + resource, 'PBXFileReference', name=lang,
                         path='Resources/' + lang + '.lproj/' + resource,
                         sourceTree='SOURCE_ROOT', lastKnownFileType='text.plist.strings')
                     for lang in ['en', 'zh-Hans']]
        variant = obj(name + resource, 'PBXVariantGroup', name=resource, children=localized, sourceTree='<group>')
        files.append(variant)
        resources.append(obj(name + resource + 'build', 'PBXBuildFile', fileRef=variant))
    groups.append(obj(name + 'group', 'PBXGroup', name=name, children=files, sourceTree='<group>'))
    product = obj(name + 'product', 'PBXFileReference', path=product_name + '.app',
                  sourceTree='BUILT_PRODUCTS_DIR', explicitFileType='wrapper.application')
    products.append(product)
    version_info = plistlib.loads((ROOT / folder / 'Info.plist').read_bytes())
    settings = dict(SWIFT_VERSION='5.0', PRODUCT_NAME=product_name,
                    PRODUCT_BUNDLE_IDENTIFIER=bundle_id, INFOPLIST_FILE=folder + '/Info.plist',
                    CODE_SIGN_STYLE='Automatic', SDKROOT=platform,
                    ASSETCATALOG_COMPILER_APPICON_NAME='AppIcon',
                    MARKETING_VERSION=version_info['CFBundleShortVersionString'], CURRENT_PROJECT_VERSION=version_info['CFBundleVersion'],
                    SWIFT_OPTIMIZATION_LEVEL='-O', ENABLE_USER_SCRIPT_SANDBOXING='YES')
    if platform == 'macosx':
        settings.update(MACOSX_DEPLOYMENT_TARGET='14.0',
                        SWIFT_OBJC_BRIDGING_HEADER='Mac/OpenSidecarMac-Bridging-Header.h',
                        ENABLE_HARDENED_RUNTIME='YES', CODE_SIGN_ENTITLEMENTS='Mac/OpenSidecarMac.entitlements')
    else:
        settings.update(IPHONEOS_DEPLOYMENT_TARGET='16.0', TARGETED_DEVICE_FAMILY='1,2',
                        CODE_SIGN_ENTITLEMENTS='iOS/OpenSidecariOS.entitlements',
                        SUPPORTED_PLATFORMS='iphoneos iphonesimulator')
        if commerce_enabled:
            settings['SWIFT_ACTIVE_COMPILATION_CONDITIONS'] = 'SIDE_DISPLAY_COMMERCE'
    target = obj(name, 'PBXNativeTarget', name=name, productName=product_name,
                 productReference=product, productType='com.apple.product-type.application',
                 buildConfigurationList=config_list(name, settings),
                 buildPhases=[obj(name + 'sources', 'PBXSourcesBuildPhase', files=sources,
                                  buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0),
                              obj(name + 'frameworks', 'PBXFrameworksBuildPhase', files=[],
                                  buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0),
                              obj(name + 'resources', 'PBXResourcesBuildPhase', files=resources,
                                  buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0)],
                 buildRules=[], dependencies=[])
    targets.append(target)

ui_reference = ''
if os.environ.get('EVA_DISPLAY_UI_TESTS') == '1':
    ui_refs, ui_sources, ui_resources = [], [], []
    paid_test_files = {'PurchaseUITests.swift', 'RefreshPhysicalUITests.swift', 'SandboxPreflightUITests.swift'}
    for file in sorted((ROOT / 'Tests').glob('*UITests.swift')):
        if file.name.startswith('.') or (not commerce_enabled and file.name in paid_test_files):
            continue
        ref = obj('uitest-' + file.name, 'PBXFileReference', path=str(file.relative_to(ROOT)), sourceTree='SOURCE_ROOT', lastKnownFileType='sourcecode.swift')
        ui_refs.append(ref)
        ui_sources.append(obj('uitest-build-' + file.name, 'PBXBuildFile', fileRef=ref))
    for file in sorted((ROOT / 'Tests').glob('*.storekit')):
        if file.name.startswith('.') or not commerce_enabled:
            continue
        ref = obj('uitest-' + file.name, 'PBXFileReference', path=str(file.relative_to(ROOT)), sourceTree='SOURCE_ROOT', lastKnownFileType='text')
        ui_refs.append(ref)
        ui_resources.append(obj('uitest-resource-' + file.name, 'PBXBuildFile', fileRef=ref))
    groups.append(obj('uitest-group', 'PBXGroup', name='UITests', children=ui_refs, sourceTree='<group>'))
    product = obj('uitest-product', 'PBXFileReference', path='EvaDisplayUITests.xctest', sourceTree='BUILT_PRODUCTS_DIR', explicitFileType='wrapper.cfbundle')
    products.append(product)
    proxy = obj('uitest-proxy', 'PBXContainerItemProxy', containerPortal=oid('project'), proxyType=1, remoteGlobalIDString=oid('EvaDisplayiOS'), remoteInfo='EvaDisplayiOS')
    dependency = obj('uitest-dependency', 'PBXTargetDependency', target=oid('EvaDisplayiOS'), targetProxy=proxy)
    ui_target = obj('uitest-target', 'PBXNativeTarget', name='EvaDisplayUITests', productName='EvaDisplayUITests',
                    productReference=product, productType='com.apple.product-type.bundle.ui-testing',
                    buildConfigurationList=config_list('uitest', dict(SWIFT_VERSION='5.0', SDKROOT='iphoneos',
                        PRODUCT_NAME='EvaDisplayUITests', PRODUCT_BUNDLE_IDENTIFIER='cn.eva.display.uitests',
                        IPHONEOS_DEPLOYMENT_TARGET='16.0', TARGETED_DEVICE_FAMILY='1,2',
                        SWIFT_ACTIVE_COMPILATION_CONDITIONS='SIDE_DISPLAY_COMMERCE' if commerce_enabled else '',
                        GENERATE_INFOPLIST_FILE='YES', TEST_TARGET_NAME='EvaDisplayiOS')),
                    buildPhases=[obj('uitest-sources', 'PBXSourcesBuildPhase', files=ui_sources, buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0),
                                 obj('uitest-frameworks', 'PBXFrameworksBuildPhase', files=[], buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0),
                                 obj('uitest-resources', 'PBXResourcesBuildPhase', files=ui_resources, buildActionMask=2147483647, runOnlyForDeploymentPostprocessing=0)],
                    buildRules=[], dependencies=[dependency])
    targets.append(ui_target)
    ui_reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ui_target}" BuildableName="EvaDisplayUITests.xctest" BlueprintName="EvaDisplayUITests" ReferencedContainer="container:EvaDisplay.xcodeproj"/>'

product_group = obj('products', 'PBXGroup', name='Products', children=products, sourceTree='<group>')
main_group = obj('rootgroup', 'PBXGroup', children=groups + [product_group], sourceTree='<group>')
project = obj('project', 'PBXProject', compatibilityVersion='Xcode 14.0', developmentRegion='en',
              knownRegions=['en', 'zh-Hans', 'Base'], mainGroup=main_group, productRefGroup=product_group,
              projectDirPath='', projectRoot='', targets=targets,
              attributes={'LastUpgradeCheck': '1600', 'BuildIndependentTargetsInParallel': 'YES'},
              buildConfigurationList=config_list('project', {'CLANG_ENABLE_MODULES': 'YES'}))
dest = ROOT / 'EvaDisplay.xcodeproj'
dest.mkdir(exist_ok=True)
(dest / 'project.pbxproj').write_bytes(plistlib.dumps(dict(archiveVersion='1', classes={}, objectVersion='56',
                                                        objects=objects, rootObject=project)))
schemes = dest / 'xcshareddata/xcschemes'
schemes.mkdir(parents=True, exist_ok=True)
for target in targets:
    name = objects[target]['name']
    if name == 'EvaDisplayUITests':
        continue
    product_name = objects[objects[target]['productReference']]['path']
    reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{product_name}" BlueprintName="{name}" ReferencedContainer="container:EvaDisplay.xcodeproj"/>'
    test_entry = f'<BuildActionEntry buildForTesting="YES" buildForRunning="NO" buildForProfiling="NO" buildForArchiving="NO" buildForAnalyzing="NO">{ui_reference}</BuildActionEntry>' if ui_reference and name == 'EvaDisplayiOS' else ''
    test_action = f'<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB"><Testables><TestableReference skipped="NO">{ui_reference}</TestableReference></Testables></TestAction>' if test_entry else ''
    scheme = f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
 <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry>{test_entry}</BuildActionEntries></BuildAction>
 {test_action}
 <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></LaunchAction>
 <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>'''
    (schemes / (name + '.xcscheme')).write_text(scheme)
print(dest)
