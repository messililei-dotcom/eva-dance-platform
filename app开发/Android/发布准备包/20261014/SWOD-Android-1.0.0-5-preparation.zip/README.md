# 安卓发布准备包 1.0.0 (5)

当前为已构建、已部署后端、已通过模拟器检查的候选版。installers 中包含实际签名 APK 和 AAB；正式发布检查仍为 NOT_READY，真机及备案/应用市场材料尚未验证。

- Android/EvaDance 是可构建工程；SDK、私有签名配置均不在包内。
- backend-delta 是本轮 App API/资料变更，backend-reference 是 App 核心和中间件参考。它们依赖原统一平台的 mini API、会员、商城及服务器模块，不能独立运行。
- 后端部署前须对照线上基线建立隔离候选工程，检查新增 import 闭包和 schema，不得把当前工作区其他未验收变更一起覆盖到生产。
- backend-tests 是需在原统一平台运行的测试；测试数据库均为内存或临时目录。
- evidence 包含实际阻断项、签名材料核对和后续验收步骤。
- 使用 SHA256SUMS.json 核对包内完整性；不包含私钥、口令、数据库、环境变量文件或本地 SDK。
